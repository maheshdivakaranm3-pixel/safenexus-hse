import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TrainingCalendarExpiryPage extends StatefulWidget {
  const TrainingCalendarExpiryPage({super.key});

  @override
  State<TrainingCalendarExpiryPage> createState() =>
      _TrainingCalendarExpiryPageState();
}

class _TrainingCalendarExpiryPageState
    extends State<TrainingCalendarExpiryPage> {
  static const Color primaryGreen = Color(0xFF159447);
  static const Color darkGreen = Color(0xFF0B5D4B);
  static const String storageKey =
      'safenexus_hse_training_calendar_expiry';

  List<Map<String, dynamic>> records = [];
  String searchText = '';
  String statusFilter = 'All';
  String categoryFilter = 'All';

  final List<String> statuses = const [
    'Planned',
    'Scheduled',
    'In Progress',
    'Completed',
    'Renewal Due',
    'Expired',
    'Cancelled',
    'Closed',
  ];

  final List<String> categories = const [
    'HSE Induction',
    'General HSE',
    'Work at Height',
    'Confined Space',
    'Lifting & Rigging',
    'Scaffolding',
    'Electrical Safety',
    'Fire Safety',
    'First Aid',
    'Emergency Response',
    'Permit to Work',
    'Environmental',
    'Chemical Safety',
    'Equipment / Machinery',
    'Defensive Driving',
    'Occupational Health',
    'Leadership / Supervisor',
    'Other',
  ];

  final List<String> recurrenceOptions = const [
    'One-Time',
    'Monthly',
    'Quarterly',
    'Half-Yearly',
    'Annual',
    'As Required',
  ];

  @override
  void initState() {
    super.initState();
    _loadRecords();
  }

  Future<void> _loadRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(storageKey) ?? [];
    final loaded = raw.map(_decode).toList();

    if (!mounted) return;
    setState(() => records = loaded);
  }

  Map<String, dynamic> _decode(String item) {
    final parts = item.split('|');

    String getValue(int index) =>
        index < parts.length ? parts[index] : '';

    return {
      'id': getValue(0),
      'workerId': getValue(1),
      'workerName': getValue(2),
      'company': getValue(3),
      'project': getValue(4),
      'site': getValue(5),
      'department': getValue(6),
      'jobRole': getValue(7),
      'trainingCode': getValue(8),
      'trainingTitle': getValue(9),
      'category': getValue(10),
      'provider': getValue(11),
      'trainer': getValue(12),
      'plannedDate': getValue(13),
      'plannedTime': getValue(14),
      'completionDate': getValue(15),
      'certificateNo': getValue(16),
      'validFrom': getValue(17),
      'validUntil': getValue(18),
      'renewalDate': getValue(19),
      'recurrence': getValue(20),
      'targetAudience': getValue(21),
      'location': getValue(22),
      'evidence': getValue(23),
      'status': getValue(24).isEmpty
          ? 'Planned'
          : getValue(24),
      'remarks': getValue(25),
      'createdAt': getValue(26),
      'updatedAt': getValue(27),
    };
  }

  String _safe(Object? value) =>
      (value?.toString() ?? '').replaceAll('|', '/').trim();

  Future<void> _saveRecords() async {
    final prefs = await SharedPreferences.getInstance();

    const keys = [
      'id',
      'workerId',
      'workerName',
      'company',
      'project',
      'site',
      'department',
      'jobRole',
      'trainingCode',
      'trainingTitle',
      'category',
      'provider',
      'trainer',
      'plannedDate',
      'plannedTime',
      'completionDate',
      'certificateNo',
      'validFrom',
      'validUntil',
      'renewalDate',
      'recurrence',
      'targetAudience',
      'location',
      'evidence',
      'status',
      'remarks',
      'createdAt',
      'updatedAt',
    ];

    final raw = records.map((record) {
      return keys.map((key) => _safe(record[key])).join('|');
    }).toList();

    await prefs.setStringList(storageKey, raw);
  }

  List<Map<String, dynamic>> get filteredRecords {
    final query = searchText.trim().toLowerCase();

    return records.where((record) {
      final searchable = record.values.join(' ').toLowerCase();

      final matchesSearch =
          query.isEmpty || searchable.contains(query);

      final matchesStatus =
          statusFilter == 'All' ||
          record['status'] == statusFilter;

      final matchesCategory =
          categoryFilter == 'All' ||
          record['category'] == categoryFilter;

      return matchesSearch &&
          matchesStatus &&
          matchesCategory;
    }).toList();
  }

  int _countStatus(String status) =>
      records.where((r) => r['status'] == status).length;

  int get _completedCount => _countStatus('Completed');

  int get _plannedCount =>
      records.where((r) =>
          r['status'] == 'Planned' ||
          r['status'] == 'Scheduled').length;

  int get _renewalDueCount =>
      records.where((r) => r['status'] == 'Renewal Due').length;

  int get _expiredCount => records
      .where((r) => r['status'] == 'Expired')
      .length;

  int get _expiringSoonCount =>
      records.where(_isExpiringSoon).length;

  int get _overdueCount =>
      records.where(_isOverdue).length;

  bool _isOverdue(Map<String, dynamic> record) {
    final planned = DateTime.tryParse(
      record['plannedDate']?.toString() ?? '',
    );

    if (planned == null) return false;

    return planned.isBefore(DateTime.now()) &&
        record['status'] != 'Completed' &&
        record['status'] != 'Cancelled' &&
        record['status'] != 'Closed';
  }

  bool _isExpiringSoon(Map<String, dynamic> record) {
    final validUntil = DateTime.tryParse(
      record['validUntil']?.toString() ?? '',
    );

    if (validUntil == null) return false;

    if (validUntil.isBefore(DateTime.now())) return false;

    final days = validUntil.difference(DateTime.now()).inDays;

    return days >= 0 && days <= 30;
  }

  Future<void> _openForm({
    Map<String, dynamic>? existing,
  }) async {
    final result =
        await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TrainingCalendarFormSheet(
        existing: existing,
        statuses: statuses,
        categories: categories,
        recurrenceOptions: recurrenceOptions,
      ),
    );

    if (result == null) return;

    final now = DateTime.now().toIso8601String();

    if (existing == null) {
      result['id'] =
          'TRN-CAL-${DateTime.now().millisecondsSinceEpoch}';
      result['createdAt'] = now;
      result['updatedAt'] = now;
      records.add(result);
    } else {
      result['id'] = existing['id'];
      result['createdAt'] = existing['createdAt'];
      result['updatedAt'] = now;

      final index = records.indexOf(existing);
      if (index >= 0) {
        records[index] = result;
      }
    }

    await _saveRecords();

    if (mounted) setState(() {});
  }

  Future<void> _deleteRecord(
    Map<String, dynamic> record,
  ) async {
    records.remove(record);
    await _saveRecords();

    if (mounted) setState(() {});
  }

  void _showDetails(Map<String, dynamic> record) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(
          record['trainingTitle']?.toString().isNotEmpty == true
              ? record['trainingTitle'].toString()
              : 'Training Calendar Details',
        ),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: record.entries
                  .where((entry) =>
                      entry.key != 'id' &&
                      entry.key != 'createdAt' &&
                      entry.key != 'updatedAt')
                  .map(
                    (entry) => Padding(
                      padding:
                          const EdgeInsets.only(bottom: 8),
                      child: Text(
                        '${_label(entry.key)}: ${entry.value}',
                        style:
                            const TextStyle(fontSize: 13),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  String _label(String key) {
    final spaced = key.replaceAllMapped(
      RegExp(r'([A-Z])'),
      (match) => ' ${match.group(1)}',
    );

    return spaced.isEmpty
        ? key
        : '${spaced[0].toUpperCase()}${spaced.substring(1)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Training Calendar & Expiry'),
        backgroundColor: darkGreen,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Add Training',
            onPressed: () => _openForm(),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: Column(
        children: [
          _dashboard(),
          Padding(
            padding:
                const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Column(
              children: [
                TextField(
                  decoration: const InputDecoration(
                    labelText:
                        'Search worker, training, certificate, site...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) => setState(
                    () => searchText = value,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child:
                          DropdownButtonFormField<String>(
                        initialValue: statusFilter,
                        decoration:
                            const InputDecoration(
                          labelText: 'Status',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          'All',
                          ...statuses,
                        ]
                            .map(
                              (value) =>
                                  DropdownMenuItem(
                                value: value,
                                child: Text(value),
                              ),
                            )
                            .toList(),
                        onChanged: (value) => setState(
                          () => statusFilter =
                              value ?? 'All',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child:
                          DropdownButtonFormField<String>(
                        initialValue: categoryFilter,
                        decoration:
                            const InputDecoration(
                          labelText: 'Category',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          'All',
                          ...categories,
                        ]
                            .map(
                              (value) =>
                                  DropdownMenuItem(
                                value: value,
                                child: Text(value),
                              ),
                            )
                            .toList(),
                        onChanged: (value) => setState(
                          () => categoryFilter =
                              value ?? 'All',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: filteredRecords.isEmpty
                ? const Center(
                    child: Text(
                      'No training calendar records found.',
                    ),
                  )
                : ListView.builder(
                    padding:
                        const EdgeInsets.all(12),
                    itemCount:
                        filteredRecords.length,
                    itemBuilder: (_, index) {
                      final record =
                          filteredRecords[index];

                      final overdue =
                          _isOverdue(record);
                      final expiring =
                          _isExpiringSoon(record);

                      return Card(
                        margin: const EdgeInsets.only(
                          bottom: 10,
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor:
                                overdue
                                    ? Colors.red
                                    : primaryGreen,
                            child: const Icon(
                              Icons.event_note,
                              color: Colors.white,
                            ),
                          ),
                          title: Text(
                            record['trainingTitle']
                                    ?.toString() ??
                                '',
                            style:
                                const TextStyle(
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            '${record['workerName']} • '
                            '${record['category']}\n'
                            '${record['plannedDate']} • '
                            '${record['status']}'
                            '${overdue ? ' • OVERDUE' : ''}'
                            '${expiring ? ' • EXPIRING ≤30 DAYS' : ''}',
                          ),
                          isThreeLine: true,
                          onTap: () =>
                              _showDetails(record),
                          trailing:
                              PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') {
                                _openForm(
                                  existing: record,
                                );
                              } else if (value ==
                                  'delete') {
                                _deleteRecord(record);
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'edit',
                                child: Text('Edit'),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child: Text('Delete'),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton:
          FloatingActionButton.extended(
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white,
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Add Training'),
      ),
    );
  }

  Widget _dashboard() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          _stat(
            'TOTAL',
            records.length,
            Icons.school,
          ),
          _stat(
            'PLANNED',
            _plannedCount,
            Icons.calendar_month,
          ),
          _stat(
            'COMPLETED',
            _completedCount,
            Icons.verified,
          ),
          _stat(
            'RENEWAL',
            _renewalDueCount,
            Icons.autorenew,
          ),
          _stat(
            'EXPIRING',
            _expiringSoonCount,
            Icons.schedule,
          ),
          _stat(
            'EXPIRED',
            _expiredCount,
            Icons.event_busy,
          ),
          _stat(
            'OVERDUE',
            _overdueCount,
            Icons.warning,
          ),
        ],
      ),
    );
  }

  Widget _stat(
    String title,
    int value,
    IconData icon,
  ) {
    return SizedBox(
      width: 100,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 10,
            horizontal: 5,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: primaryGreen,
                size: 20,
              ),
              const SizedBox(height: 3),
              Text(
                '$value',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                title,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 9),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrainingCalendarFormSheet
    extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final List<String> statuses;
  final List<String> categories;
  final List<String> recurrenceOptions;

  const _TrainingCalendarFormSheet({
    required this.existing,
    required this.statuses,
    required this.categories,
    required this.recurrenceOptions,
  });

  @override
  State<_TrainingCalendarFormSheet> createState() =>
      _TrainingCalendarFormSheetState();
}

class _TrainingCalendarFormSheetState
    extends State<_TrainingCalendarFormSheet> {
  static const Color primaryGreen =
      Color(0xFF159447);
  static const Color darkGreen =
      Color(0xFF0B5D4B);

  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController>
      controllers = {};

  String category = 'General HSE';
  String recurrence = 'One-Time';
  String status = 'Planned';

  @override
  void initState() {
    super.initState();

    const fields = [
      'workerId',
      'workerName',
      'company',
      'project',
      'site',
      'department',
      'jobRole',
      'trainingCode',
      'trainingTitle',
      'provider',
      'trainer',
      'plannedDate',
      'plannedTime',
      'completionDate',
      'certificateNo',
      'validFrom',
      'validUntil',
      'renewalDate',
      'targetAudience',
      'location',
      'evidence',
      'remarks',
    ];

    for (final field in fields) {
      controllers[field] =
          TextEditingController(
        text:
            widget.existing?[field]?.toString() ??
                '',
      );
    }

    final existingCategory =
        widget.existing?['category']?.toString();

    if (existingCategory != null &&
        widget.categories.contains(existingCategory)) {
      category = existingCategory;
    }

    final existingRecurrence =
        widget.existing?['recurrence']?.toString();

    if (existingRecurrence != null &&
        widget.recurrenceOptions
            .contains(existingRecurrence)) {
      recurrence = existingRecurrence;
    }

    final existingStatus =
        widget.existing?['status']?.toString();

    if (existingStatus != null &&
        widget.statuses.contains(existingStatus)) {
      status = existingStatus;
    }
  }

  @override
  void dispose() {
    for (final controller in controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  TextEditingController _controller(
    String key,
  ) =>
      controllers[key]!;

  String? _required(String? value) {
    if (value == null ||
        value.trim().isEmpty) {
      return 'Required';
    }

    return null;
  }

  Widget _field(
    String key,
    String label, {
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding:
          const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller: _controller(key),
        maxLines: maxLines,
        validator: validator,
        decoration: InputDecoration(
          labelText: label,
          border:
              const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.only(
        top: 6,
        bottom: 10,
      ),
      child: Text(
        title,
        style: const TextStyle(
          color: darkGreen,
          fontSize: 14,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height:
            MediaQuery.of(context).size.height *
                0.95,
        decoration:
            const BoxDecoration(
          color: Colors.white,
          borderRadius:
              BorderRadius.vertical(
            top: Radius.circular(22),
          ),
        ),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.all(14),
                color: darkGreen,
                child: const Row(
                  children: [
                    Icon(
                      Icons.event_note,
                      color: Colors.white,
                    ),
                    SizedBox(width: 10),
                    Text(
                      'Training Calendar & Expiry Record',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding:
                      const EdgeInsets.all(16),
                  children: [
                    _section(
                      'WORKER & DEPLOYMENT',
                    ),
                    _field(
                      'workerId',
                      'Worker / Employee ID',
                      validator: _required,
                    ),
                    _field(
                      'workerName',
                      'Worker Name',
                      validator: _required,
                    ),
                    _field(
                      'company',
                      'Company / Contractor',
                      validator: _required,
                    ),
                    _field(
                      'project',
                      'Project',
                    ),
                    _field(
                      'site',
                      'Site / Location',
                    ),
                    _field(
                      'department',
                      'Department',
                    ),
                    _field(
                      'jobRole',
                      'Job Role / Trade',
                    ),
                    _section(
                      'TRAINING DETAILS',
                    ),
                    _field(
                      'trainingCode',
                      'Training / Course Code',
                    ),
                    _field(
                      'trainingTitle',
                      'Training / Course Title',
                      validator: _required,
                    ),
                    DropdownButtonFormField<String>(
                      initialValue: category,
                      decoration:
                          const InputDecoration(
                        labelText:
                            'Training Category',
                        border:
                            OutlineInputBorder(),
                      ),
                      items: widget.categories
                          .map(
                            (value) =>
                                DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(
                        () => category =
                            value ??
                                widget.categories
                                    .first,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _field(
                      'provider',
                      'Training Provider',
                    ),
                    _field(
                      'trainer',
                      'Trainer / Instructor',
                    ),
                    _field(
                      'targetAudience',
                      'Target Audience / Required Workers',
                      maxLines: 2,
                    ),
                    _section(
                      'CALENDAR & COMPLETION',
                    ),
                    _field(
                      'plannedDate',
                      'Planned Training Date (YYYY-MM-DD)',
                      validator: _required,
                    ),
                    _field(
                      'plannedTime',
                      'Planned Time',
                    ),
                    _field(
                      'location',
                      'Training Location',
                    ),
                    _field(
                      'completionDate',
                      'Completion Date (YYYY-MM-DD)',
                    ),
                    DropdownButtonFormField<String>(
                      initialValue: recurrence,
                      decoration:
                          const InputDecoration(
                        labelText:
                            'Training Recurrence',
                        border:
                            OutlineInputBorder(),
                      ),
                      items: widget.recurrenceOptions
                          .map(
                            (value) =>
                                DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(
                        () => recurrence =
                            value ??
                                widget.recurrenceOptions
                                    .first,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _field(
                      'renewalDate',
                      'Renewal / Refresher Date (YYYY-MM-DD)',
                    ),
                    _section(
                      'CERTIFICATE & EXPIRY',
                    ),
                    _field(
                      'certificateNo',
                      'Certificate Number',
                    ),
                    _field(
                      'validFrom',
                      'Valid From (YYYY-MM-DD)',
                    ),
                    _field(
                      'validUntil',
                      'Valid Until (YYYY-MM-DD)',
                    ),
                    _section(
                      'STATUS & RECORD',
                    ),
                    DropdownButtonFormField<String>(
                      initialValue: status,
                      decoration:
                          const InputDecoration(
                        labelText:
                            'Training Status',
                        border:
                            OutlineInputBorder(),
                      ),
                      items: widget.statuses
                          .map(
                            (value) =>
                                DropdownMenuItem(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(
                        () => status =
                            value ?? 'Planned',
                      ),
                    ),
                    const SizedBox(height: 10),
                    _field(
                      'evidence',
                      'Evidence / Certificate File Reference',
                      maxLines: 2,
                    ),
                    _field(
                      'remarks',
                      'Remarks / Renewal Action',
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Expanded(
                      child:
                          OutlinedButton(
                        onPressed: () =>
                            Navigator.pop(
                          context,
                        ),
                        child:
                            const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child:
                          ElevatedButton.icon(
                        style:
                            ElevatedButton.styleFrom(
                          backgroundColor:
                              primaryGreen,
                          foregroundColor:
                              Colors.white,
                        ),
                        onPressed: _save,
                        icon: const Icon(
                          Icons.save,
                        ),
                        label: const Text(
                          'Save Training',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _save() {
    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    final data =
        <String, dynamic>{};

    for (final entry
        in controllers.entries) {
      data[entry.key] =
          entry.value.text.trim();
    }

    data['category'] = category;
    data['recurrence'] = recurrence;
    data['status'] = status;

    Navigator.pop(context, data);
  }
}
