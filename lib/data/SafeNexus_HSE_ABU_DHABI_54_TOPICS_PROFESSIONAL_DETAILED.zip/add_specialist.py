from pathlib import Path
import re
p=Path('/mnt/data/ad_deep/lib/data/abu_dhabi_guidelines.dart')
s=p.read_text()

specialists=[
('ad_hazardous_materials','Hazardous Materials Management','Hazardous Materials','CoP 1.0', 'classification, inventory, storage, handling, exposure control, SDS, spill response and disposal'),
('ad_asbestos','Asbestos-Containing Materials Management','Asbestos Management','CoP 1.1', 'survey, identification, isolation, licensed removal, exposure prevention, air monitoring and clearance'),
('ad_lead_exposure','Lead Exposure Management','Lead Exposure','CoP 1.2', 'lead sources, exposure assessment, hygiene, respiratory protection, medical surveillance and decontamination'),
('ad_occupational_noise','Occupational Noise Management','Occupational Noise','CoP 3.0', 'noise assessment, engineering controls, hearing protection, audiometry, zoning and exposure management'),
('ad_vibration','Occupational Vibration Management','Vibration','CoP 3.1', 'hand-arm vibration, whole-body vibration, exposure assessment, equipment selection, maintenance and health monitoring'),
('ad_first_aid','First Aid and Medical Emergency Treatment','First Aid','CoP 4.0', 'first-aid needs assessment, trained responders, equipment, emergency communication, treatment and records'),
('ad_medical_surveillance','Occupational Health Screening and Medical Surveillance','Medical Surveillance','CoP 5.0', 'health screening, exposure-linked surveillance, confidentiality, fitness decisions, referral and records'),
('ad_workplace_amenities','General Workplace Amenities and Welfare','Workplace Amenities','CoP 8.0', 'sanitation, drinking water, washing, rest, changing, welfare facilities, housekeeping and accessibility'),
('ad_workplace_wellness','Workplace Wellness and Worker Wellbeing','Workplace Wellness','CoP 9.0', 'wellbeing, fatigue, health promotion, supportive culture, early support, welfare and monitoring'),
('ad_manual_handling','Manual Handling and Ergonomics','Manual Handling','CoP 14.0', 'manual handling assessment, lifting, pushing, pulling, task design, mechanical aids and musculoskeletal risk'),
('ad_special_needs','OSH Requirements for People with Special Needs','Inclusive OSH','CoP 16.0', 'inclusive risk assessment, accessibility, emergency arrangements, reasonable adjustments and communication'),
('ad_safety_signage','Safety Signage and Signals','Safety Signage','CoP 17.0', 'sign selection, placement, visibility, symbols, traffic signals, temporary signs and maintenance'),
('ad_safety_in_design','Safety in Design for Construction','Safety in Design','CoP 20.0', 'design risk identification, elimination, maintainability, temporary works, constructability and handover information'),
('ad_permit_to_work','Permit to Work Systems','Permit to Work','CoP 21.0', 'permit roles, isolation, simultaneous work, gas testing, handover, suspension, extension and closure'),
('ad_barricading','Barricading of Hazards','Barricading','CoP 22.0', 'hazard segregation, barrier selection, exclusion zones, signage, access control and inspection'),
('ad_loto','Lockout Tagout and Energy Isolation','LOTO / Isolation','CoP 24.0', 'energy identification, isolation, locking, verification, group isolation, restoration and records'),
('ad_driver_fatigue','Driver Fatigue Prevention','Driver Fatigue','CoP 25.0', 'journey planning, working hours, rest, fatigue signs, scheduling, vehicle use and incident prevention'),
('ad_lone_remote','Lone Working and Remote Locations','Lone Working','CoP 30.0', 'risk assessment, communication, check-in, emergency response, remote access and worker welfare'),
('ad_water_safety','Working On, Over or Adjacent to Water','Water Safety','CoP 31.0', 'fall prevention, drowning risk, life-saving equipment, rescue, boats, weather and water conditions'),
('ad_lifting_equipment','Safe Use of Lifting Equipment and Accessories','Lifting Equipment','CoP 34.0', 'selection, inspection, certification, rigging, load limits, accessories, storage and lifting practices'),
('ad_portable_power_tools','Portable Power Tools','Portable Power Tools','CoP 35.0', 'tool selection, guards, electrical safety, abrasive wheels, inspection, PPE and operator competence'),
('ad_plant_equipment','Plant and Equipment Safety','Plant & Equipment','CoP 36.0', 'selection, guarding, inspection, operator competence, maintenance, isolation and mobile-plant interfaces'),
('ad_ladders','Ladder Safety','Ladders','CoP 37.0', 'selection, inspection, positioning, securing, access, work limitations and fall prevention'),
('ad_concrete_placing','Concrete Placing Equipment','Concrete Placing','CoP 38.0', 'pumps, hoses, pressure, line stability, blockages, washout, exclusion zones and maintenance'),
('ad_overhead_underground','Overhead and Underground Services','Utility Services','CoP 39.0', 'service identification, exclusion distances, locating, permit-to-dig, overhead lines and emergency response'),
('ad_falsework','Falsework and Formwork Safety','Falsework / Formwork','CoP 40.0', 'design, loading, erection, stability, striking, inspection, temporary works and sequencing'),
('ad_steel_erection','Steel Erection Safety','Steel Erection','CoP 41.0', 'erection planning, lifting, stability, bolting, work at height, exclusion zones and temporary bracing'),
('ad_precast','Precast Construction Safety','Precast Construction','CoP 42.0', 'lifting, temporary stability, connections, storage, transport, erection sequence and exclusion zones'),
('ad_temporary_structures','Temporary Structures Safety','Temporary Structures','CoP 43.0', 'design, loads, foundations, stability, weather, inspection, modification and dismantling'),
('ad_machine_guarding','Machine Guarding and Machinery Safety','Machine Guarding','CoP 47.0', 'moving parts, guards, interlocks, isolation, access, maintenance, inspection and operator safety'),
]

# Insert topic definitions before final ]; of abuDhabiGuidelines. Locate first closing \n]; after const list.
list_end=s.index('\n];', s.index('const List<ReferenceTopic> abuDhabiGuidelines'))
insert=[]
for id,title,short,cop,focus in specialists:
    insert.append("ReferenceTopic(")
    insert.append(f"id: '{id}',")
    insert.append(f"title: '{title}',")
    insert.append(f"shortTitle: '{short}',")
    insert.append("category: 'Abu Dhabi',")
    insert.append("guidelineCategory: GuidelineCategory.abuDhabi,")
    insert.append("authority: 'Abu Dhabi Public Health Centre (ADPHC) / ADOSH-SF',")
    insert.append("jurisdiction: 'Abu Dhabi',")
    insert.append(f"description: 'Professional learning and field-reference guidance for {focus}. This topic should be read with the current {cop} and project-specific requirements.',")
    insert.append("keyRequirements: [")
    insert.extend([
        "'Identify the hazards, exposed persons, applicable work conditions and credible consequences for the subject.',",
        "'Use the current ADOSH-SF Code of Practice and applicable authority requirements as the compliance baseline.',",
        "'Assess the task and select controls using the hierarchy of controls.',",
        "'Define competent persons, equipment, inspection, training and supervision requirements.',",
        "'Control changes, interfaces and emergency conditions associated with the subject.',",
        "'Maintain objective records and verify implementation at the workface.',",
    ])
    insert.append("],")
    insert.append("safetyControls: [")
    insert.extend([f"'{x}'," for x in [short, 'Risk assessment', 'Competence & supervision', 'Inspection & maintenance', 'PPE / exposure control', 'Emergency response', 'Records & assurance']])
    insert.append("],")
    insert.append("responsibilities: [")
    insert.extend([
        "'Management provides resources, competent people and governance.',",
        "'Supervisors implement the approved controls and verify them in the field.',",
        "'Workers follow the controls, use equipment correctly and report defects or hazards.',",
        "'HSE personnel provide advice, assurance and escalation support.',",
    ])
    insert.append("],")
    insert.append("references: [")
    insert.extend([f"'{cop} – {title}',", "'ADPHC – ADOSH-SF Code of Practices',", "'Applicable ADOSH-SF mechanisms, technical guidelines and project procedures',", "'Project-specific approved risk assessment / RAMS / permit where applicable',"])
    insert.append("],")
    insert.append("),\n")

s=s[:list_end+1]+'\n'+ '\n'.join(insert) + s[list_end+1:]

# Build specialist detailed content before final map closure. Find last occurrence of '\n};' (the map closure).
map_end=s.rfind('\n};')
icons={
'ad_hazardous_materials':'warning_amber_outlined','ad_asbestos':'masks_outlined','ad_lead_exposure':'science_outlined','ad_occupational_noise':'hearing_outlined','ad_vibration':'vibration_outlined','ad_first_aid':'medical_services_outlined','ad_medical_surveillance':'medical_information_outlined','ad_workplace_amenities':'wc_outlined','ad_workplace_wellness':'favorite_outline','ad_manual_handling':'accessibility_new_outlined','ad_special_needs':'accessible_outlined','ad_safety_signage':'signpost_outlined','ad_safety_in_design':'architecture_outlined','ad_permit_to_work':'assignment_turned_in_outlined','ad_barricading':'block_outlined','ad_loto':'lock_outline','ad_driver_fatigue':'local_shipping_outlined','ad_lone_remote':'person_pin_circle_outlined','ad_water_safety':'water_outlined','ad_lifting_equipment':'construction_outlined','ad_portable_power_tools':'build_outlined','ad_plant_equipment':'precision_manufacturing_outlined','ad_ladders':'stairs_outlined','ad_concrete_placing':'foundation_outlined','ad_overhead_underground':'cable_outlined','ad_falsework':'view_agenda_outlined','ad_steel_erection':'vertical_align_top_outlined','ad_precast':'domain_outlined','ad_temporary_structures':'other_houses_outlined','ad_machine_guarding':'settings_outlined'}
# Fallback icon if a symbol is unavailable in older Flutter: use Icons.security_outlined for all risky custom names.
# To maximize compatibility, use common Material icons only.
compat={k:'Icons.security_outlined' for k in icons}
compat.update({
'ad_hazardous_materials':'Icons.warning_amber_outlined','ad_asbestos':'Icons.warning_outlined','ad_lead_exposure':'Icons.science_outlined','ad_occupational_noise':'Icons.hearing_outlined','ad_vibration':'Icons.vibration_outlined','ad_first_aid':'Icons.medical_services_outlined','ad_medical_surveillance':'Icons.medical_information_outlined','ad_workplace_amenities':'Icons.wc_outlined','ad_workplace_wellness':'Icons.favorite_outline','ad_manual_handling':'Icons.accessibility_new_outlined','ad_special_needs':'Icons.accessible_outlined','ad_safety_signage':'Icons.signpost_outlined','ad_safety_in_design':'Icons.architecture_outlined','ad_permit_to_work':'Icons.assignment_turned_in_outlined','ad_barricading':'Icons.block_outlined','ad_loto':'Icons.lock_outline','ad_driver_fatigue':'Icons.local_shipping_outlined','ad_lone_remote':'Icons.person_pin_circle_outlined','ad_water_safety':'Icons.water_outlined','ad_lifting_equipment':'Icons.construction_outlined','ad_portable_power_tools':'Icons.build_outlined','ad_plant_equipment':'Icons.precision_manufacturing_outlined','ad_ladders':'Icons.stairs_outlined','ad_concrete_placing':'Icons.foundation_outlined','ad_overhead_underground':'Icons.cable_outlined','ad_falsework':'Icons.view_agenda_outlined','ad_steel_erection':'Icons.vertical_align_top_outlined','ad_precast':'Icons.domain_outlined','ad_temporary_structures':'Icons.other_houses_outlined','ad_machine_guarding':'Icons.settings_outlined'})

def q(x): return "'"+x.replace("'","\\'")+"'"

# Subject-specific section sets and points generated from a focused profile.
profiles={
'ad_hazardous_materials':('Hazardous Materials',['inventory and classification','SDS and hazard communication','storage and compatibility','handling and transfer','exposure and PPE','spill and emergency response','waste and disposal']),
'ad_asbestos':('Asbestos-Containing Materials',['survey and identification','work planning and isolation','licensed removal controls','containment and negative pressure','worker protection and hygiene','air monitoring and clearance','waste and decontamination']),
'ad_lead_exposure':('Lead Exposure',['source identification','exposure assessment','engineering controls','hygiene and PPE','health surveillance','decontamination and waste','incident and field verification']),
'ad_occupational_noise':('Occupational Noise',['noise source assessment','engineering controls','administrative exposure control','hearing protection','health surveillance','communication and signage','field verification']),
'ad_vibration':('Vibration',['source and exposure assessment','tool and equipment selection','maintenance and engineering controls','work organisation','worker health and symptoms','PPE and limitations','field verification']),
'ad_first_aid':('First Aid',['needs assessment','first-aid facilities','trained responders','medical communication','treatment and casualty management','records and replenishment','drills and verification']),
'ad_medical_surveillance':('Medical Surveillance',['risk-based screening','exposure-linked surveillance','fitness and restrictions','confidentiality','referral and follow-up','records and trend review','field verification']),
'ad_workplace_amenities':('Workplace Amenities',['water and sanitation','washing and hygiene','rest and changing facilities','cleanliness and housekeeping','accessibility and special needs','maintenance and inspection','worker feedback']),
'ad_workplace_wellness':('Workplace Wellness',['wellbeing programme','fatigue and recovery','health promotion','supportive culture','work organisation','early intervention','monitoring and improvement']),
'ad_manual_handling':('Manual Handling and Ergonomics',['task assessment','lifting and carrying','pushing and pulling','mechanical aids','workstation and layout','worker technique and training','musculoskeletal monitoring']),
'ad_special_needs':('Inclusive OSH',['inclusive risk assessment','accessibility','communication','emergency evacuation','reasonable adjustments','contractor and visitor inclusion','verification']),
'ad_safety_signage':('Safety Signage',['sign selection','placement and visibility','mandatory and warning signs','traffic and pedestrian signals','temporary signs','inspection and maintenance','worker understanding']),
'ad_safety_in_design':('Safety in Design',['design risk identification','elimination and hierarchy','construction sequencing','maintenance and future use','temporary works and interfaces','design review and residual risk','handover information']),
'ad_permit_to_work':('Permit to Work',['permit roles and authorisation','hazard identification','isolation and gas testing','simultaneous operations','permit issue and handover','suspension and extension','closure and records']),
'ad_barricading':('Barricading of Hazards',['hazard identification','barrier selection','exclusion zones','signage and access control','public and contractor interfaces','inspection and changes','removal and close-out']),
'ad_loto':('Lockout Tagout and Isolation',['energy identification','shutdown and isolation','lock and tag application','verification and zero-energy state','group isolation','restoration and handover','records and auditing']),
'ad_driver_fatigue':('Driver Fatigue',['journey risk assessment','work and driving hours','rest and recovery','fatigue recognition','vehicle and route planning','supervision and reporting','incident learning']),
'ad_lone_remote':('Lone Working',['risk assessment','communication and check-in','location and access','emergency response','welfare and first aid','technology and monitoring','verification and rescue']),
'ad_water_safety':('Water Safety',['water hazard assessment','edge protection','life-saving equipment','boats and marine interfaces','weather and water conditions','rescue and emergency','inspection and field verification']),
'ad_lifting_equipment':('Lifting Equipment',['equipment selection','inspection and certification','lifting accessories','rigging and load control','storage and maintenance','operator and rigger competence','field verification']),
'ad_portable_power_tools':('Portable Power Tools',['tool selection','guards and safe operation','electrical safety','abrasive and cutting tools','inspection and maintenance','PPE and training','field verification']),
'ad_plant_equipment':('Plant and Equipment',['selection and suitability','guarding and safety devices','operator competence','inspection and maintenance','isolation and repair','mobile plant interfaces','field verification']),
'ad_ladders':('Ladders',['selection and limitations','inspection','positioning and securing','access and three-point contact','work restrictions','storage and maintenance','field verification']),
'ad_concrete_placing':('Concrete Placing Equipment',['pump and equipment selection','line and hose control','pressure and blockage hazards','placing operations','washout and cleaning','inspection and maintenance','emergency response']),
'ad_overhead_underground':('Utility Services',['service identification','permit-to-dig','underground locating','overhead line controls','excavation and plant interfaces','service strike emergency','verification and records']),
'ad_falsework':('Falsework and Formwork',['design and engineering','foundations and stability','erection sequence','loading and concrete pressure','inspection and modification','striking and dismantling','field verification']),
'ad_steel_erection':('Steel Erection',['erection planning','lifting and placement','temporary stability','connections and bolting','work at height','exclusion zones','inspection and handover']),
'ad_precast':('Precast Construction',['design and lifting points','transport and storage','lifting and rigging','temporary stability','connections and fixing','erection sequence','inspection and handover']),
'ad_temporary_structures':('Temporary Structures',['design and approval','loads and foundations','erection and stability','weather and environmental effects','inspection and modification','use and access','dismantling and close-out']),
'ad_machine_guarding':('Machine Guarding',['hazard identification','fixed and interlocked guards','access and nip points','isolation for maintenance','inspection and testing','operator training','field verification']),
}

# Generic but subject-specific detailed prose builder.
section_templates={
'inventory and classification':('Scope and Identification',['Identify all sources, products or conditions covered by the subject before work begins.','Classify the hazard using the current product information, task assessment and applicable OSH requirements.','Identify exposed persons, routes of exposure and credible consequences.','Create a controlled inventory or register where the subject requires one.','Review the inventory when materials, equipment or work methods change.','Use competent technical advice where classification is uncertain.']),
'survey and identification':('Survey and Identification',['Complete a competent survey before intrusive work or exposure where the subject requires identification.','Record locations, condition, extent and affected work areas.','Mark or communicate identified hazards without creating additional exposure.','Use representative information and investigate unknown conditions before work starts.','Control access to identified hazard areas.','Update the survey when the scope or physical condition changes.']),
'source identification':('Source Identification',['Identify the source, pathway and exposed people before selecting controls.','Consider normal, abnormal, maintenance and emergency conditions.','Include adjacent work groups and contractor interfaces.','Use measurements or specialist assessment when observation is insufficient.','Prioritise high-consequence sources for immediate control.','Review sources after changes or incidents.']),
}

def make_sections(key, profile):
    subject, sections=profile
    result=[]
    for i,sec in enumerate(sections):
        # tailored titles
        title=sec.replace(' and ',' & ').title()
        if sec=='SDS and hazard communication': title='Safety Data & Hazard Communication'
        elif sec=='worker health and symptoms': title='Worker Health & Symptoms'
        elif sec=='field verification': title='Field Verification & Assurance'
        elif sec=='work organisation': title='Work Organisation & Exposure Control'
        elif sec=='inspection and maintenance': title='Inspection & Maintenance'
        elif sec=='inspection and changes': title='Inspection & Change Control'
        elif sec=='removal and close-out': title='Removal & Close-Out'
        elif sec=='rest and recovery': title='Rest & Recovery'
        elif sec=='communication and signage': title='Communication & Signage'
        elif sec=='design risk identification': title='Design Risk Identification'
        elif sec=='permit issue and handover': title='Permit Issue & Handover'
        elif sec=='closure and records': title='Closure & Records'
        elif sec=='shutdown and isolation': title='Shutdown & Isolation'
        elif sec=='lock and tag application': title='Lock & Tag Application'
        elif sec=='verification and zero-energy state': title='Verification & Zero-Energy State'
        elif sec=='restoration and handover': title='Restoration & Handover'
        elif sec=='journey risk assessment': title='Journey Risk Assessment'
        elif sec=='work and driving hours': title='Work & Driving Hours'
        elif sec=='location and access': title='Location & Access Control'
        elif sec=='edge protection': title='Edge Protection & Access'
        elif sec=='life-saving equipment': title='Life-Saving Equipment'
        elif sec=='boats and marine interfaces': title='Boats & Marine Interfaces'
        elif sec=='equipment selection': title='Equipment Selection'
        elif sec=='lifting accessories': title='Lifting Accessories'
        elif sec=='tool selection': title='Tool Selection'
        elif sec=='guards and safe operation': title='Guards & Safe Operation'
        elif sec=='selection and suitability': title='Selection & Suitability'
        elif sec=='guarding and safety devices': title='Guarding & Safety Devices'
        elif sec=='pump and equipment selection': title='Pump & Equipment Selection'
        elif sec=='line and hose control': title='Line & Hose Control'
        elif sec=='service identification': title='Service Identification'
        elif sec=='permit-to-dig': title='Permit-to-Dig Controls'
        elif sec=='design and engineering': title='Design & Engineering'
        elif sec=='foundations and stability': title='Foundations & Stability'
        elif sec=='lifting and placement': title='Lifting & Placement'
        elif sec=='temporary stability': title='Temporary Stability'
        elif sec=='connections and bolting': title='Connections & Bolting'
        elif sec=='design and lifting points': title='Design & Lifting Points'
        elif sec=='transport and storage': title='Transport & Storage'
        elif sec=='connections and fixing': title='Connections & Fixing'
        elif sec=='loads and foundations': title='Loads & Foundations'
        elif sec=='fixed and interlocked guards': title='Fixed & Interlocked Guards'
        elif sec=='access and nip points': title='Access & Nip Points'
        elif sec=='isolation for maintenance': title='Isolation for Maintenance'
        elif sec=='inspection and testing': title='Inspection & Testing'
        elif sec=='inventory and classification': title='Inventory & Classification'
        elif sec=='work planning and isolation': title='Work Planning & Isolation'
        elif sec=='licensed removal controls': title='Licensed Removal Controls'
        elif sec=='containment and negative pressure': title='Containment & Negative Pressure'
        elif sec=='worker protection and hygiene': title='Worker Protection & Hygiene'
        elif sec=='air monitoring and clearance': title='Air Monitoring & Clearance'
        elif sec=='waste and decontamination': title='Waste & Decontamination'
        elif sec=='exposure assessment': title='Exposure Assessment'
        elif sec=='engineering controls': title='Engineering Controls'
        elif sec=='hygiene and PPE': title='Hygiene & PPE'
        elif sec=='decontamination and waste': title='Decontamination & Waste'
        elif sec=='incident and field verification': title='Incident & Field Verification'
        elif sec=='noise source assessment': title='Noise Source Assessment'
        elif sec=='engineering controls': title='Engineering Controls'
        elif sec=='administrative exposure control': title='Administrative Exposure Control'
        elif sec=='hearing protection': title='Hearing Protection'
        elif sec=='health surveillance': title='Health Surveillance'
        elif sec=='vibration': title='Vibration Exposure Control'
        elif sec=='tool and equipment selection': title='Tool & Equipment Selection'
        elif sec=='maintenance and engineering controls': title='Maintenance & Engineering Controls'
        elif sec=='worker health and symptoms': title='Worker Health & Symptoms'
        elif sec=='PPE and limitations': title='PPE & Limitations'
        elif sec=='needs assessment': title='Needs Assessment'
        elif sec=='first-aid facilities': title='First-Aid Facilities'
        elif sec=='trained responders': title='Trained Responders'
        elif sec=='medical communication': title='Medical Communication'
        elif sec=='treatment and casualty management': title='Treatment & Casualty Management'
        elif sec=='records and replenishment': title='Records & Replenishment'
        elif sec=='drills and verification': title='Drills & Verification'
        elif sec=='risk-based screening': title='Risk-Based Screening'
        elif sec=='exposure-linked surveillance': title='Exposure-Linked Surveillance'
        elif sec=='fitness and restrictions': title='Fitness & Restrictions'
        elif sec=='referral and follow-up': title='Referral & Follow-Up'
        elif sec=='trend review': title='Records & Trend Review'
        elif sec=='water and sanitation': title='Water & Sanitation'
        elif sec=='washing and hygiene': title='Washing & Hygiene'
        elif sec=='rest and changing facilities': title='Rest & Changing Facilities'
        elif sec=='cleanliness and housekeeping': title='Cleanliness & Housekeeping'
        elif sec=='accessibility and special needs': title='Accessibility & Special Needs'
        elif sec=='maintenance and inspection': title='Maintenance & Inspection'
        elif sec=='worker feedback': title='Worker Feedback'
        elif sec=='wellbeing programme': title='Wellbeing Programme'
        elif sec=='fatigue and recovery': title='Fatigue & Recovery'
        elif sec=='health promotion': title='Health Promotion'
        elif sec=='supportive culture': title='Supportive Culture'
        elif sec=='work organisation': title='Work Organisation'
        elif sec=='early intervention': title='Early Intervention'
        elif sec=='task assessment': title='Task Assessment'
        elif sec=='lifting and carrying': title='Lifting & Carrying'
        elif sec=='pushing and pulling': title='Pushing & Pulling'
        elif sec=='mechanical aids': title='Mechanical Aids'
        elif sec=='workstation and layout': title='Workstation & Layout'
        elif sec=='worker technique and training': title='Worker Technique & Training'
        elif sec=='musculoskeletal monitoring': title='Musculoskeletal Monitoring'
        elif sec=='inclusive risk assessment': title='Inclusive Risk Assessment'
        elif sec=='accessibility': title='Accessibility'
        elif sec=='communication': title='Communication'
        elif sec=='emergency evacuation': title='Emergency Evacuation'
        elif sec=='reasonable adjustments': title='Reasonable Adjustments'
        elif sec=='contractor and visitor inclusion': title='Contractor & Visitor Inclusion'
        elif sec=='verification': title='Verification'
        elif sec=='sign selection': title='Sign Selection'
        elif sec=='placement and visibility': title='Placement & Visibility'
        elif sec=='mandatory and warning signs': title='Mandatory & Warning Signs'
        elif sec=='traffic and pedestrian signals': title='Traffic & Pedestrian Signals'
        elif sec=='temporary signs': title='Temporary Signs'
        elif sec=='signage and access control': title='Signage & Access Control'
        elif sec=='public and contractor interfaces': title='Public & Contractor Interfaces'
        elif sec=='removal and close-out': title='Removal & Close-Out'
        elif sec=='design risk identification': title='Design Risk Identification'
        elif sec=='elimination and hierarchy': title='Elimination & Hierarchy of Controls'
        elif sec=='construction sequencing': title='Construction Sequencing'
        elif sec=='maintenance and future use': title='Maintenance & Future Use'
        elif sec=='temporary works and interfaces': title='Temporary Works & Interfaces'
        elif sec=='design review and residual risk': title='Design Review & Residual Risk'
        elif sec=='handover information': title='Handover Information'
        # Build detailed items.
        items=[
            f'For {subject.lower()}, define the scope of {sec} before work starts and identify the people, equipment, materials and interfaces that can be affected.',
            f'Apply the current ADOSH-SF requirements relevant to {subject.lower()} and translate them into clear project controls, responsibilities and verification criteria.',
            f'Use the hierarchy of controls for {sec}: eliminate or reduce the hazard first, then use engineering, administrative and PPE controls as appropriate.',
            f'Ensure competent personnel understand {sec}, have the required information and equipment, and know the conditions that require work to stop or be reassessed.',
            f'Inspect and document the condition of controls for {sec}; defects, deviations or changing conditions should be corrected, escalated and reverified.',
            f'Link {sec} to the project risk assessment, RAMS, permits, training, emergency arrangements and incident-learning process so the subject is managed as part of the full OSH system.',
        ]
        # Add one topic-specific practical point.
        items.append(f'Field practice: before exposure to {subject.lower()}, the supervisor should walk the work area, confirm the critical controls for {sec}, ask workers to explain the controls and verify the arrangement at the point of work.')
        result.append((title,items))
    return result

# Insert entries before map closure.
newmap=[]
for key in profiles:
    sections=make_sections(key,profiles[key])
    newmap.append(f"  '{key}': [")
    for title,items in sections:
        newmap.append('    _AbuDhabiSection(')
        newmap.append(f"      title: {q(title)},")
        newmap.append(f"      icon: {compat[key]},")
        newmap.append('      items: [')
        for item in items: newmap.append(f'        {q(item)},')
        newmap.append('      ],')
        newmap.append('    ),')
    newmap.append('  ],')
newmap_text='\n'.join(newmap)+'\n'
s=s[:map_end]+'\n'+newmap_text+s[map_end:]
p.write_text(s)
print('specialist topics added',len(specialists),'chars',len(s),'lines',len(s.splitlines()))
