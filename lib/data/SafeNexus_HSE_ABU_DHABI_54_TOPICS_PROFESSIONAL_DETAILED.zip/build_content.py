from pathlib import Path
import re

p=Path('/mnt/data/ad_deep/lib/data/abu_dhabi_guidelines.dart')
s=p.read_text()
marker='const Map<String, List<_AbuDhabiSection>> _abuDhabiDetailedContent = {'
idx=s.index(marker)
prefix=s[:idx]

# Each topic: 8 subject-specific sections, each 7 study points.
data={
'ad_oshad_sf':(
'ADOSH-SF Framework & Governance','policy_outlined',[
('Framework purpose and scope',[
'Understand ADOSH-SF as Abu Dhabi\'s occupational safety and health management framework and distinguish the framework from individual site procedures.',
'Identify the entity, workplace, project activities, workforce and operational interfaces that fall within the OSH management system scope.',
'Use the current ADPHC legislation library as the controlled source for framework documents, mechanisms, Codes of Practice and guidance.',
'Determine which sector regulatory authority and competent authority requirements apply to the activity and project.',
'Identify where project approvals, permits, NOCs, client standards or municipality requirements add controls beyond the baseline framework.',
'Keep a documented process for reviewing regulatory changes and communicating changes to affected personnel.',
'Use the framework as a management system: requirement → risk → control → responsibility → evidence → verification → improvement.'
]),
('Governance, leadership and accountability',[
'Assign clear OSH leadership at management, project, HSE, supervision and workforce levels.',
'Define authorities for stopping unsafe work, escalating significant risk and approving risk controls.',
'Provide competent resources, time, equipment, welfare arrangements and specialist support required for effective OSH management.',
'Include OSH performance in management meetings, project reviews, contractor reviews and operational decisions.',
'Ensure senior leaders verify field conditions rather than relying only on reports or dashboard statistics.',
'Hold accountable persons responsible for implementing assigned controls and closing verified actions.',
'Review accountability when organisational structure, project scope or high-risk activities change.'
]),
('System elements and integration',[
'Integrate policy, objectives, risk management, operational controls, consultation, competence, emergency management and assurance into one coherent system.',
'Link procedures and RAMS to the hazards identified in the project risk register.',
'Ensure permits, inspections, toolbox talks and competency records support the same critical controls defined in the management system.',
'Use document control so only approved current procedures and forms are used in the field.',
'Build interfaces between contractor systems and the principal project OSHMS before work begins.',
'Ensure occupational health and welfare controls are treated as core OSH system elements rather than separate welfare activities.',
'Use management review to identify system weaknesses and improvement priorities.'
]),
('Compliance assurance and evidence',[
'Create a legal and OSH obligations register covering applicable framework requirements, Codes of Practice, mechanisms and project conditions.',
'Map important obligations to procedures, responsible persons, evidence and verification frequency.',
'Use inspections and audits to verify implementation at the point of work.',
'Retain objective evidence such as permits, inspection records, training records, certificates, monitoring results and corrective-action close-outs.',
'Escalate repeated or significant non-compliance according to the project escalation process.',
'Verify that corrective actions address root causes and not only visible symptoms.',
'Periodically test whether compliance evidence remains valid, current and traceable.'
]),
('Consultation, communication and worker participation',[
'Provide workers with understandable information about hazards, controls, emergency arrangements and changes affecting their work.',
'Use toolbox talks, pre-task briefings, safety meetings and consultation channels appropriate to the workforce.',
'Encourage workers to report hazards, near misses and control failures without bypassing required reporting processes.',
'Include workers and relevant contractors in hazard identification and control reviews where their practical knowledge is valuable.',
'Provide a route for complaints and concerns to be received, investigated and closed.',
'Check understanding through questions, demonstrations and field verification rather than attendance alone.',
'Feed worker observations and lessons learned back into procedures and risk assessments.'
]),
('Performance, assurance and continual improvement',[
'Use leading indicators such as inspections, critical-control verification, training completion and action closure alongside lagging indicators.',
'Trend high-potential events, recurring findings, unsafe conditions and repeated control failures.',
'Use management reviews to decide priorities, resources and system improvements.',
'Investigate serious or repeated failures to identify organisational and control-system causes.',
'Capture lessons learned and formally communicate those relevant to other work areas or projects.',
'Verify improvement actions after implementation to confirm that risk actually reduced.',
'Keep the improvement cycle active through plan → implement → check → act.'
]),
('Field verification and professional practice',[
'Before mobilisation, confirm applicable authority requirements, project conditions, competent resources and critical controls.',
'Before high-risk work, verify that the approved method, risk assessment, permit and competent workforce are aligned.',
'During work, inspect the critical control at the exposure point and stop or reassess if conditions differ from the approved plan.',
'After incidents or significant changes, review the risk assessment and relevant management-system controls.',
'Use photographs, inspection records and action evidence where appropriate to demonstrate field implementation.',
'Never treat a generic company procedure as proof of project compliance without verifying site-specific implementation.',
'Use current official Abu Dhabi requirements as the final compliance reference before making regulatory decisions.'
]),
]),
'ad_oshms':(
'Occupational Safety & Health Management System','settings_outlined',[
('OSHMS structure and scope',[
'Define the OSHMS boundaries, legal entity, project locations, activities, employees, contractors and operational interfaces.',
'Establish a controlled OSH policy supported by measurable objectives and management commitment.',
'Define processes for risk management, operational control, consultation, competence, emergency response and assurance.',
'Integrate OSH requirements into normal project planning, procurement, construction and operational decisions.',
'Identify processes that require specialist support such as occupational hygiene, lifting, electrical or confined-space expertise.',
'Control outsourced activities and contractor interfaces through defined responsibilities and assurance arrangements.',
'Review the system scope whenever the business or project changes materially.'
]),
('Planning and objectives',[
'Use legal and project requirements to establish relevant OSH objectives and priorities.',
'Base objectives on significant risks, compliance obligations, incident trends and operational needs.',
'Assign owners, resources, measures and review dates for each objective.',
'Balance leading measures with outcome measures so management can detect deterioration early.',
'Ensure project and contractor objectives support the principal project OSH objectives.',
'Review objectives when risk profile, programme or regulatory requirements change.',
'Document decisions and actions arising from management review of objectives.'
]),
('Risk management integration',[
'Identify hazards systematically before work and whenever activities, plant, materials, people or conditions change.',
'Use suitable risk assessment methods for routine, non-routine and high-risk activities.',
'Apply the hierarchy of controls before relying on administrative controls or PPE.',
'Link critical controls to supervisors, permits, RAMS, inspections and worker briefings.',
'Use dynamic assessment when site conditions change unexpectedly.',
'Verify that residual risk is acceptable under the project approval process before work proceeds.',
'Keep risk assessments current and accessible to the workforce.'
]),
('Operational control',[
'Control high-risk activities through approved procedures, RAMS, permits and competent supervision.',
'Use pre-start checks and task briefings to confirm readiness before exposure begins.',
'Control equipment through inspection, maintenance, certification and operator competency.',
'Control temporary works, interfaces, simultaneous operations and changes through formal processes.',
'Ensure emergency arrangements remain practical for the actual work location and access constraints.',
'Use site inspections to verify that written controls are reflected in physical conditions.',
'Control deviations through stop-work, reassessment and formal approval rather than informal workarounds.'
]),
('Competence, consultation and communication',[
'Define competence requirements for roles, tasks and safety-critical activities.',
'Provide induction, task-specific training, toolbox talks and refresher learning as appropriate.',
'Verify competence through assessment, observation or practical demonstration where required.',
'Consult workers and contractors about hazards, changes and practical control effectiveness.',
'Provide information in languages and formats understood by the workforce.',
'Ensure supervisors can explain the critical controls they are expected to enforce.',
'Keep training and competency evidence controlled and traceable.'
]),
('Monitoring, audit and management review',[
'Plan inspections and audits based on risk, legal requirements, previous findings and operational performance.',
'Use objective evidence to test whether controls are implemented and effective.',
'Analyse trends rather than treating every finding as an isolated event.',
'Ensure corrective actions have owners, due dates, risk-based priorities and effectiveness checks.',
'Conduct management reviews that consider incidents, leading indicators, compliance, resources and improvement needs.',
'Escalate serious or recurring deficiencies to appropriate management levels.',
'Keep assurance results as evidence for continual improvement.'
]),
('Field application and verification',[
'Confirm the OSHMS is visible at the workface through current RAMS, permits, competent people and active supervision.',
'Ask workers to explain the hazard, critical control and response if the control fails.',
'Check whether actual work matches the approved method rather than accepting paperwork alone.',
'Observe interactions between trades and contractors where interface risk may be higher than individual-task risk.',
'Use stop-work and escalation processes when critical controls are absent or ineffective.',
'Capture learning from field verification and feed it into the OSHMS.',
'Verify current official requirements before treating an OSHMS control as regulatory compliance.'
]),
]),
'ad_risk_management':(
'Abu Dhabi Risk Management and Control','rule_outlined',[
('Risk management process',[
'Define the activity, task, people exposed, equipment, environment and credible unwanted outcomes before assessing risk.',
'Identify hazards from normal, abnormal, non-routine, maintenance and emergency conditions.',
'Consider workers, contractors, visitors, public interfaces and people who may be more vulnerable to the hazard.',
'Assess risk using the project-approved risk matrix and record the basis for the rating.',
'Select controls using the hierarchy of controls and prioritise elimination or engineering solutions where reasonably practicable.',
'Reassess residual risk after controls are defined and before authorisation to proceed.',
'Review the assessment after incidents, changes, new information or evidence that controls are ineffective.'
]),
('Hazard identification methods',[
'Use site inspections, task observation, design review, previous incidents and worker consultation to identify hazards.',
'Break complex work into logical steps so task-specific hazards are not hidden inside broad descriptions.',
'Consider simultaneous operations, adjacent work, public interfaces and temporary conditions.',
'Identify energy sources such as electrical, mechanical, hydraulic, pressure, gravity, thermal and stored energy.',
'Consider chemical, biological, physical, ergonomic and psychosocial hazards where relevant.',
'Include environmental conditions such as heat, wind, rain, fog, poor visibility, dust and flooding where applicable.',
'Check the risk register against actual work fronts so new hazards are captured early.'
]),
('Hierarchy of controls',[
'Prefer elimination of the hazardous task, material, energy source or exposure where feasible.',
'Use substitution to reduce hazard severity or exposure when elimination is not practical.',
'Use engineering controls such as guarding, barriers, interlocks, ventilation, edge protection or remote operation.',
'Use administrative controls such as procedures, permits, scheduling, supervision, signage and training as supporting controls.',
'Use PPE as the final line of defence and ensure it is compatible with the task and other PPE.',
'Identify critical controls whose failure could lead to serious harm and assign clear verification responsibilities.',
'Check that controls do not introduce new hazards or transfer risk to another work group.'
]),
('Task and dynamic risk assessment',[
'Conduct task-level assessment before starting work and brief the workforce on the relevant controls.',
'Use dynamic reassessment when weather, access, equipment, sequence, personnel or surrounding activities change.',
'Stop and reassess when a critical assumption in the approved method becomes invalid.',
'Ensure supervisors have authority to suspend work when risk is no longer controlled.',
'Record significant changes and update the formal assessment when the change is persistent or material.',
'Use pre-task briefings to confirm controls rather than simply reading the RAMS.',
'Verify that workers can identify the stop-work triggers relevant to their task.'
]),
('Critical risk management',[
'Identify activities with credible fatality or life-changing injury potential and define their critical controls.',
'Use a focused critical-control register for high-consequence risks where appropriate.',
'Assign named owners for critical controls and specify verification frequency.',
'Check control performance in the field using observable criteria.',
'Escalate any missing or degraded critical control immediately.',
'Use learning from high-potential incidents to strengthen critical controls across similar activities.',
'Keep critical-risk controls simple enough to be understood and verified at the workface.'
]),
('Risk communication and approval',[
'Ensure risk assessments are approved by persons with the authority and competence required by the project system.',
'Communicate significant risks and controls to workers, supervisors, contractors and affected interfaces.',
'Use clear language, diagrams or demonstrations when the workforce may have literacy or language limitations.',
'Ensure permits and RAMS reference the same hazards and critical controls as the risk assessment.',
'Provide access to current approved assessments at the point of work.',
'Prevent uncontrolled copies from becoming the working version.',
'Confirm understanding through questioning, observation and field verification.'
]),
('Monitoring and improvement',[
'Use inspection findings, observations, incidents and near misses to test whether risk assumptions remain valid.',
'Analyse recurring hazards and repeated control failures for systemic causes.',
'Update risk assessments when new equipment, chemicals, methods or legal requirements are introduced.',
'Close risk-related actions based on evidence of effective control, not only completion of an administrative task.',
'Review high-risk assessments at planned intervals and before critical stages of work.',
'Use lessons learned to improve generic templates without losing project-specific detail.',
'Maintain traceability from identified hazard to control, owner and verification evidence.'
]),
]),
'ad_hse_plan':(
'HSE Plan for Building & Construction','description_outlined',[
('Plan purpose and project profile',[
'Prepare the project HSE plan as a practical management document for building, construction or infrastructure activities.',
'Describe the project scope, location, programme, work phases, workforce profile, interfaces and significant hazards.',
'Identify the client, consultant, contractor, HSE team and other parties with defined responsibilities.',
'Include applicable authority, permit, approval and project-specific HSE conditions.',
'Use the current DMT/municipality guidance applicable to the project and verify additional authority conditions.',
'Link the plan to the project risk register, RAMS, emergency arrangements and inspection programme.',
'Control revisions so the field team uses the current approved plan.'
]),
('Organisation and responsibilities',[
'Define project management accountability for HSE performance and resource provision.',
'Define HSE personnel roles, authority, competency and reporting lines.',
'Define consultant and contractor responsibilities for review, supervision and compliance.',
'Define supervisor responsibilities for implementing controls at the workface.',
'Define worker responsibilities for following controls and reporting hazards and incidents.',
'Define contractor and subcontractor interface responsibilities to avoid gaps or duplicated authority.',
'Provide escalation arrangements for serious or unresolved HSE issues.'
]),
('Risk and operational control',[
'Identify significant project risks and the controls required for each construction phase.',
'Integrate RAMS, permits, inspection and testing plans, lifting plans and temporary works controls as applicable.',
'Control high-risk activities through competent planning, approval and supervision.',
'Consider simultaneous operations and changes in the construction sequence.',
'Include traffic, public protection, temporary facilities and environmental interfaces where relevant.',
'Provide arrangements for managing non-conformance and stopping unsafe work.',
'Ensure the plan reflects actual site conditions and is reviewed when conditions change.'
]),
('Emergency and occupational health',[
'Define credible emergencies including fire, medical emergency, rescue, collapse, spill, severe weather and utility incidents as relevant.',
'Provide emergency contacts, alarm methods, access routes, assembly arrangements and competent response resources.',
'Plan first aid and medical emergency arrangements appropriate to the project workforce and hazards.',
'Address occupational health risks including heat, noise, vibration, dust, chemicals, ergonomics and medical fitness as applicable.',
'Include welfare, drinking water, sanitation, rest areas and heat-management arrangements.',
'Test emergency arrangements through drills and exercises and record corrective actions.',
'Ensure emergency plans remain usable at each work front, not only at the main site office.'
]),
('Training and communication',[
'Provide site induction before access to work areas and task-specific training before exposure.',
'Maintain competency requirements for safety-critical roles and equipment operators.',
'Use toolbox talks and pre-task briefings linked to current activities and risks.',
'Provide language-appropriate safety information and verify understanding.',
'Communicate project changes, incidents, lessons learned and emergency arrangements.',
'Keep attendance and competency records controlled and traceable.',
'Assess whether training changed behaviour and field performance rather than measuring attendance alone.'
]),
('Inspection, audit and reporting',[
'Establish planned inspections for site conditions, equipment, temporary works, housekeeping and critical controls.',
'Conduct audits based on legal obligations, project requirements and risk priorities.',
'Provide incident and near-miss reporting arrangements with defined escalation.',
'Track corrective actions to verified close-out and analyse recurring findings.',
'Use performance dashboards or periodic reports to communicate trends to management.',
'Retain objective evidence supporting compliance claims and authority submissions.',
'Review the plan when assurance results show that controls are not effective.'
]),
('Plan approval, revision and field use',[
'Obtain required project approvals before mobilisation or relevant work stages.',
'Brief key personnel on the plan and ensure they know where controlled copies are available.',
'Review the plan after major scope, design, sequence, contractor or regulatory changes.',
'Ensure subcontractor plans and RAMS are consistent with the project HSE plan.',
'Use field inspections to test whether planned arrangements exist in practice.',
'Withdraw obsolete versions and prevent uncontrolled copies from remaining in use.',
'Verify current official authority requirements before treating the plan as a compliance submission.'
]),
]),
'ad_roles_responsibilities':(
'OSH Roles, Responsibilities and Accountability','groups_outlined',[
('Leadership and management duties',[
'Provide visible OSH leadership and ensure safety is integrated into business and project decisions.',
'Provide sufficient competent people, equipment, welfare, time and budget for risk control.',
'Approve objectives and review OSH performance at appropriate management levels.',
'Ensure significant risks are escalated and not accepted informally without authorised review.',
'Hold managers accountable for implementing controls within their areas of responsibility.',
'Ensure contractor performance is governed rather than assumed to be the contractor\'s responsibility alone.',
'Lead by example through field engagement and verification of critical controls.'
]),
('HSE function and professional advice',[
'Provide competent OSH advice and support risk assessment, planning, inspection and assurance.',
'Monitor compliance and report significant deficiencies to appropriate management.',
'Coordinate incident reporting and investigation according to the project system.',
'Support training, consultation, emergency planning and performance monitoring.',
'Maintain professional independence when identifying unacceptable risk or serious non-compliance.',
'Escalate matters beyond HSE authority to management or the relevant authority where required.',
'Keep professional knowledge current with ADOSH-SF updates and applicable technical requirements.'
]),
('Project managers and supervisors',[
'Plan work so hazards are controlled before workers are exposed.',
'Ensure approved RAMS, permits and competent resources are available at the workface.',
'Verify critical controls during execution and stop work when controls fail.',
'Coordinate simultaneous operations and interfaces between trades and contractors.',
'Conduct or support pre-task briefings and confirm worker understanding.',
'Correct unsafe conditions promptly and escalate issues that cannot be resolved locally.',
'Review performance trends and recurring findings within their work areas.'
]),
('Workers and worker participation',[
'Follow approved procedures, permits and instructions and use required controls correctly.',
'Inspect personal protective equipment and report defects or limitations.',
'Report hazards, near misses, incidents and control failures promptly.',
'Participate in toolbox talks, consultations and risk-control discussions.',
'Exercise stop-work authority according to project arrangements when serious uncontrolled risk is identified.',
'Protect others by maintaining barriers, housekeeping and exclusion zones relevant to their work.',
'Participate honestly in investigations and learning activities.'
]),
('Contractor and subcontractor interfaces',[
'Clarify responsibility boundaries before work starts and document interfaces for shared risks.',
'Prequalify contractors based on relevant competence, resources, experience and OSH performance.',
'Coordinate RAMS, permits, emergency arrangements and site rules across contractor interfaces.',
'Ensure subcontractors receive induction and are included in project consultation and assurance.',
'Monitor contractor performance using field evidence and leading indicators.',
'Escalate repeated non-compliance through contractual and project governance channels.',
'Ensure changes in subcontractor scope or personnel trigger appropriate reassessment.'
]),
('Delegation, authority and escalation',[
'Delegation must be clear about the task, authority, competence and accountability retained by the delegating manager.',
'Define who may approve RAMS, permits, lifting plans, isolations and changes according to project procedures.',
'Provide escalation routes for unresolved risk, resource shortages and significant non-compliance.',
'Prevent conflicting instructions by maintaining clear reporting lines and controlled documents.',
'Ensure temporary duty changes are communicated to affected teams.',
'Verify that nominated persons are actually competent and available to perform assigned responsibilities.',
'Review responsibility matrices when project organisation changes.'
]),
('Field accountability checks',[
'Ask supervisors to demonstrate the controls they are accountable for rather than only describing them.',
'Check whether workers know who to contact for safety concerns and emergencies.',
'Verify that assigned actions are closed by the responsible person with evidence.',
'Compare organisational charts and responsibility matrices with actual site staffing.',
'Check that safety-critical decisions are made by authorised competent persons.',
'Use management walkdowns to verify leadership engagement and control effectiveness.',
'Capture recurring responsibility gaps as system improvement actions.'
]),
]),
'ad_incident_reporting':(
'Incident, Accident and Near-Miss Reporting','report_outlined',[
('Immediate response and scene control',[
'Protect life first by providing emergency assistance and contacting the appropriate response service.',
'Stop affected work and control secondary hazards such as electrical energy, moving plant, fire or structural instability.',
'Prevent unauthorised access to the scene where preservation of evidence is required.',
'Arrange first aid and medical treatment appropriate to the injury or exposure.',
'Notify the responsible supervisor and project HSE function according to the escalation procedure.',
'Preserve relevant physical evidence, photographs, equipment status and documents where safe and lawful.',
'Do not disturb the scene unnecessarily before authorised evidence collection.'
]),
('Incident classification and notification',[
'Distinguish incidents, near misses, unsafe conditions, occupational health cases and other reportable events according to the applicable system.',
'Capture date, time, location, activity, people involved, immediate consequences and initial controls.',
'Identify actual outcome and credible potential outcome where the project system requires high-potential classification.',
'Use the current ADOSH-SF mechanism and project procedure to determine reporting requirements and timescales.',
'Escalate serious or potentially serious events immediately rather than waiting for a completed investigation.',
'Coordinate required authority, client and insurance notifications through authorised personnel.',
'Retain submission evidence and reference numbers where electronic reporting is used.'
]),
('Investigation methodology',[
'Appoint investigators with suitable competence, independence and understanding of the activity.',
'Define the investigation scope and preserve evidence before conditions change.',
'Collect physical evidence, photographs, documents, permits, RAMS, training records and relevant digital records.',
'Interview witnesses using open questions and avoid leading or blame-focused questioning.',
'Reconstruct the sequence of events and identify failed or missing controls.',
'Distinguish immediate causes from underlying and organisational causes.',
'Ensure investigation conclusions are supported by evidence and not assumptions.'
]),
('Root causes and corrective actions',[
'Examine whether planning, design, supervision, competence, equipment, procedures or organisational factors contributed.',
'Identify failed barriers and why the system allowed those barriers to fail.',
'Prioritise corrective actions that strengthen engineering or system controls.',
'Assign action owners and risk-based due dates and define required evidence of completion.',
'Verify effectiveness in the field after actions are implemented.',
'Communicate relevant lessons without disclosing unnecessary personal information.',
'Update risk assessments, RAMS, training or procedures when investigation findings require change.'
]),
('Near misses and proactive learning',[
'Encourage reporting of near misses and high-potential events as learning opportunities.',
'Capture the hazardous condition, potential consequence and controls that prevented harm.',
'Analyse near-miss trends for recurring weaknesses before injury occurs.',
'Use toolbox talks and alerts to share learning rapidly with affected work groups.',
'Close near-miss actions with the same discipline applied to actual incidents.',
'Avoid creating a culture where reporting is discouraged by excessive blame or paperwork.',
'Use leading-indicator trends to measure whether reporting quality and control effectiveness are improving.'
]),
('Records, confidentiality and evidence',[
'Maintain controlled incident records with unique identifiers and revision history.',
'Protect personal and medical information and share it only with authorised persons.',
'Retain supporting evidence according to legal, client and project retention requirements.',
'Ensure electronic reports are complete, accurate and traceable to source information.',
'Keep investigation approvals and action close-outs linked to the original event.',
'Prevent unauthorised alteration of records after submission.',
'Use records for trend analysis without compromising confidentiality.'
]),
('Field verification and learning closure',[
'Confirm corrective actions are physically implemented where the incident occurred.',
'Check similar work fronts for the same hazard so learning is not limited to one location.',
'Verify that revised RAMS or procedures were briefed to the workforce.',
'Observe whether behaviour and controls changed after the intervention.',
'Escalate repeated incidents or recurring causes to management review.',
'Capture lessons learned in a reusable knowledge base or project alert system.',
'Verify current reporting requirements before making regulatory notification decisions.'
]),
]),
'ad_training_competency':(
'Training, Competency and Safety Communication','school_outlined',[
('Training needs analysis',[
'Identify competence requirements from job roles, risk assessments, legal requirements and safety-critical tasks.',
'Distinguish awareness training from demonstrated competence for tasks where error can cause serious harm.',
'Consider new starters, transferred workers, temporary workers, supervisors, operators and specialist roles.',
'Identify refresher or reassessment needs based on validity, performance, incidents and changes.',
'Include contractor and subcontractor training within the project competence system.',
'Use current approved course and qualification requirements for regulated or safety-critical activities.',
'Maintain a training matrix showing required, completed, expired and pending competencies.'
]),
('Induction and orientation',[
'Provide project induction before access to operational areas.',
'Cover site hazards, emergency arrangements, welfare, reporting, PPE, traffic routes and stop-work expectations.',
'Provide task or area-specific orientation when the risk profile differs from the general induction.',
'Use language, visual aids and demonstrations appropriate to the workforce.',
'Check understanding through questions or practical demonstrations where appropriate.',
'Prevent uninducted personnel from entering controlled work areas.',
'Record induction completion and maintain retrievable evidence.'
]),
('Competence assessment',[
'Define objective competence criteria for each safety-critical role.',
'Use practical assessment or workplace observation where knowledge alone cannot demonstrate competence.',
'Ensure assessors are themselves competent and authorised.',
'Address gaps through supervised practice, retraining or reassessment.',
'Verify certificates and licences where required before assigning the task.',
'Control expiry dates and prevent expired qualifications from being treated as current.',
'Link competence evidence to the person and role actually performed on site.'
]),
('Supervisor and leadership capability',[
'Train supervisors in hazard identification, risk control, RAMS, permit systems and emergency response relevant to their work.',
'Ensure supervisors can recognise when work conditions differ from the approved plan.',
'Teach supervisors how to conduct effective pre-task briefings and verify understanding.',
'Provide skills for incident reporting, evidence preservation and initial response.',
'Use field coaching to strengthen leadership behaviours and critical-control verification.',
'Assess supervisory competence through observation, not attendance alone.',
'Provide additional support where supervisors manage unfamiliar or unusually high-risk work.'
]),
('Communication and worker learning',[
'Use toolbox talks linked to current hazards, recent events and planned work.',
'Use demonstrations, visual instructions and practical examples for complex tasks.',
'Encourage two-way communication so workers can challenge ineffective controls.',
'Provide multilingual or simplified communication where necessary for comprehension.',
'Record key learning topics and attendance without treating attendance as proof of competence.',
'Reinforce critical controls through repeated point-of-work communication.',
'Check learning through questions and observations in the field.'
]),
('Training records and assurance',[
'Maintain controlled records for induction, training, assessment, certification and refresher requirements.',
'Use a competency matrix to identify gaps before mobilisation or high-risk work.',
'Periodically sample records against people actually working on site.',
'Check certificates for authenticity, validity and scope where required.',
'Investigate incidents or performance failures that indicate a competence gap.',
'Close training actions with evidence of improved competence.',
'Keep records available for authorised project and regulatory verification.'
]),
('Field verification and continual improvement',[
'Observe workers performing safety-critical tasks and compare practice with training requirements.',
'Ask workers to explain the hazard, control and emergency response relevant to their task.',
'Use incident and inspection trends to update training needs.',
'Reassess competence after significant changes in equipment, method or risk.',
'Use lessons learned to improve induction and toolbox-talk content.',
'Ensure contractor competence remains current throughout the project.',
'Verify current Abu Dhabi competency and registration requirements for regulated OSH roles.'
]),
]),
'ad_contractor_management':(
'Contractor and Subcontractor Management','handshake_outlined',[
('Prequalification and selection',[
'Assess contractor competence, relevant experience, resources, OSH performance and management arrangements before appointment.',
'Confirm that the contractor can provide competent personnel for safety-critical activities.',
'Review relevant licences, registrations, inspection certificates and technical qualifications.',
'Assess subcontractor control arrangements and how the main contractor manages lower-tier organisations.',
'Include project-specific hazards and OSH expectations in tender and contract requirements.',
'Use risk-based prequalification rather than relying only on document quantity.',
'Retain objective evaluation records and approvals.'
]),
('Mobilisation and onboarding',[
'Complete contractor mobilisation checks before work starts.',
'Provide project induction, emergency information, site rules and access requirements.',
'Review contractor RAMS, permits, competency records and equipment certification as applicable.',
'Confirm welfare, accommodation, transport and worker-support arrangements where within project scope.',
'Clarify reporting lines, stop-work authority and escalation routes.',
'Coordinate contractor activities with the project programme and simultaneous operations.',
'Prevent mobilisation of uncontrolled equipment, chemicals or personnel.'
]),
('Contractor risk and method control',[
'Require contractor risk assessments and RAMS to address actual project conditions and interfaces.',
'Review high-risk work submissions before exposure begins and ensure required approvals are obtained.',
'Confirm critical controls and verification responsibilities between principal contractor and subcontractor.',
'Control changes through formal review rather than allowing field deviations to become normal practice.',
'Ensure contractor permits align with the project permit system.',
'Coordinate emergency response and rescue arrangements across contractor boundaries.',
'Verify that contractor workers understand the approved method and critical controls.'
]),
('Performance monitoring and assurance',[
'Use inspections, audits, observations, incident trends and action closure to evaluate contractor performance.',
'Focus assurance on critical risks and control effectiveness rather than paperwork volume.',
'Hold periodic contractor performance reviews with documented actions.',
'Escalate serious or repeated non-compliance through defined governance and contractual channels.',
'Recognise strong reporting and proactive control verification where it supports the safety culture.',
'Check that subcontractor performance is visible to the principal contractor.',
'Use performance trends to inform future contractor selection and improvement.'
]),
('Interface and simultaneous operations',[
'Identify shared hazards where multiple contractors occupy the same work area.',
'Use coordination meetings and look-ahead planning to manage conflicting activities.',
'Control shared access, lifting zones, temporary services, traffic routes and emergency routes.',
'Assign one clear authority for shared controls where responsibility could otherwise be ambiguous.',
'Communicate changes in sequence or work area to all affected contractors.',
'Use permits or coordination controls for high-risk interfaces where applicable.',
'Review interface risk after incidents, near misses or significant schedule changes.'
]),
('Competence, welfare and worker engagement',[
'Verify contractor worker competence for assigned tasks and equipment.',
'Ensure workers receive project induction and task-specific information.',
'Include contractor workers in toolbox talks, consultations and emergency drills.',
'Check welfare arrangements and heat-management measures where applicable.',
'Provide reporting routes for contractor workers to raise safety concerns.',
'Ensure fatigue, transport and accommodation issues are considered where they can affect work risk.',
'Use worker feedback to identify contractor interface problems.'
]),
('Close-out and learning',[
'Complete demobilisation checks for temporary works, equipment, materials, waste and outstanding HSE actions.',
'Confirm all incidents, actions and records are closed or transferred to the responsible project owner.',
'Retain contractor performance records according to project requirements.',
'Capture lessons learned for future packages and contractor selection.',
'Review recurring contractor issues at project management level.',
'Ensure final site condition is safe after contractor departure.',
'Verify that regulatory or client close-out requirements have been completed.'
]),
]),
'ad_emergency_management':(
'Emergency Management and Response','emergency_outlined',[
('Emergency planning and scenarios',[
'Identify credible emergencies from project hazards, site location, workforce and surrounding environment.',
'Consider fire, medical emergency, fall rescue, confined-space rescue, collapse, electrical incident, spill and severe weather as applicable.',
'Define emergency command, communication, alarm and escalation arrangements.',
'Provide emergency maps showing access routes, assembly areas, firefighting equipment and key hazards.',
'Ensure plans address remote work fronts and changing construction layouts.',
'Coordinate emergency arrangements with client, contractor, authority and external response interfaces.',
'Review scenarios after changes, incidents and drills.'
]),
('Fire and life safety',[
'Provide suitable fire prevention and emergency arrangements for the hazards present.',
'Control ignition sources, combustible materials, temporary electrical systems and hot work.',
'Keep emergency routes, exits and access for emergency vehicles clear.',
'Provide appropriate fire-fighting equipment and ensure inspection and access are maintained.',
'Provide trained persons and fire-watch arrangements where required by the task.',
'Communicate alarm signals, evacuation routes and assembly arrangements to workers.',
'Test readiness through drills and record improvement actions.'
]),
('Medical and first aid',[
'Assess first-aid requirements based on workforce size, hazards, site remoteness and work activities.',
'Provide trained first-aiders and accessible first-aid equipment appropriate to the risk.',
'Define emergency medical contact and transport arrangements.',
'Keep access routes suitable for ambulance or emergency vehicle response.',
'Ensure emergency information includes exact site location and access instructions.',
'Review arrangements for remote work fronts, night work and isolated tasks.',
'Record and review emergency medical responses for improvement.'
]),
('Rescue and specialist response',[
'Identify rescue requirements for work at height, confined spaces, excavation, lifting incidents and other credible scenarios.',
'Ensure rescue equipment is suitable, inspected and accessible before the hazardous task begins.',
'Assign competent rescue personnel and define backup arrangements.',
'Plan communication and casualty transfer routes before work starts.',
'Prevent unplanned rescue attempts that could expose additional workers to the same hazard.',
'Coordinate specialist external rescue support where internal capability is insufficient.',
'Rehearse realistic rescue scenarios and correct weaknesses.'
]),
('Emergency communication and evacuation',[
'Use alarm and communication methods that can be heard or seen in the actual work environment.',
'Provide multilingual emergency instructions where required for comprehension.',
'Identify assembly areas and account for workers, visitors and contractors.',
'Provide arrangements for people who may need assistance during evacuation.',
'Keep emergency contact lists current and controlled.',
'Ensure temporary work areas have practical evacuation routes.',
'Test communication systems during drills and after site changes.'
]),
('Drills, exercises and readiness',[
'Plan drills based on credible scenarios and project risk rather than conducting repetitive demonstrations only.',
'Involve relevant contractors, supervisors and emergency resources.',
'Measure alarm response, evacuation, accountability, communication and command effectiveness.',
'Identify gaps in equipment, competence, access or coordination.',
'Assign corrective actions and verify close-out before the next relevant high-risk activity.',
'Use lessons from real incidents to improve scenarios and procedures.',
'Keep drill records and trend recurring weaknesses.'
]),
('Field readiness verification',[
'Check emergency equipment at the point of work before high-risk activities begin.',
'Verify access for emergency vehicles and rescue teams is not blocked by materials or plant.',
'Ask workers how they would raise an alarm and where they would go.',
'Check that supervisors know their emergency responsibilities and escalation routes.',
'Confirm changes in work location are reflected in emergency arrangements.',
'Inspect assembly areas, signage, lighting and communication arrangements.',
'Verify current authority and project emergency requirements before finalising the plan.'
]),
]),
'ad_work_at_height':(
'Work at Height and Fall Prevention','height_outlined',[
('Planning and hierarchy of controls',[
'Avoid work at height where the task can be completed safely from ground level.',
'Prefer collective fall prevention such as permanent floors, guardrails, platforms and edge protection.',
'Use suitable access equipment designed for the task and site conditions.',
'Plan rescue before using fall-arrest systems.',
'Assess dropped-object risk in parallel with fall risk.',
'Consider weather, lighting, wind, surface condition and simultaneous operations.',
'Use current ADOSH-SF CoP 23 requirements and project procedures as the compliance basis.'
]),
('Access systems and platforms',[
'Use properly designed and maintained scaffolds, platforms, MEWPs or other approved access systems.',
'Provide safe access and egress and keep access routes clear.',
'Prevent unauthorised modification of temporary platforms or edge protection.',
'Ensure work platforms have suitable guardrails, toe protection and safe working surfaces where required.',
'Inspect access equipment before use and after relevant changes or events.',
'Control loading, occupancy and equipment limits according to manufacturer or design requirements.',
'Provide adequate lighting for access and work areas.'
]),
('Fall protection and harness systems',[
'Use fall restraint where feasible to prevent a fall rather than relying on arrest after a fall.',
'When fall arrest is necessary, verify anchor suitability, clearance, compatible equipment and rescue arrangements.',
'Inspect harnesses, lanyards, lifelines and connectors before use and after events that may affect integrity.',
'Prevent incompatible connections and improper anchorage.',
'Control swing-fall and sharp-edge risks associated with lifelines and lanyards.',
'Ensure workers are trained and competent in equipment use and limitations.',
'Keep equipment identification and inspection records where required.'
]),
('Roof, edge and fragile-surface work',[
'Identify unprotected edges, openings, fragile surfaces and skylights before access.',
'Provide physical barriers, covers or engineered systems appropriate to the hazard.',
'Mark fragile surfaces and prevent access by unauthorised personnel.',
'Use suitable crawl boards or access systems where required by the task and design.',
'Control materials and tools so they cannot fall through openings or from edges.',
'Inspect temporary edge protection after relocation, impact or adverse conditions.',
'Include roof work in rescue and emergency planning.'
]),
('Ladders and portable access',[
'Use ladders only for tasks where they are suitable and stable and where safer alternatives are not required.',
'Inspect ladders before use and remove defective equipment from service.',
'Position ladders on firm, level surfaces and secure them against movement.',
'Maintain appropriate hand contact and avoid overreaching or carrying loads that compromise balance.',
'Prevent unauthorised use of makeshift platforms, boxes or unstable surfaces.',
'Control ladder access around openings, traffic and other work activities.',
'Train workers in ladder selection, positioning and limitations.'
]),
('Dropped objects and exclusion zones',[
'Secure tools, materials and equipment when working above people or vulnerable areas.',
'Use toe boards, tool lanyards, debris containment or other suitable controls where needed.',
'Create exclusion zones below elevated work and control access.',
'Prevent loose materials from accumulating at edges or platforms.',
'Coordinate lifting and overhead work with work-at-height activities.',
'Inspect barriers and containment systems throughout the task.',
'Investigate dropped-object near misses as high-value learning events.'
]),
('Rescue, supervision and verification',[
'Prepare a realistic rescue plan before work begins and ensure equipment and competent rescuers are available.',
'Consider suspension trauma and time-critical recovery after a fall arrest.',
'Provide supervision appropriate to risk, worker competence and site complexity.',
'Ask workers to identify fall hazards, critical controls and rescue arrangements before starting.',
'Inspect critical controls at the workface rather than relying on paperwork.',
'Stop work when edge protection, access, anchorage or rescue arrangements are compromised.',
'Review current official CoP 23 requirements and project-specific conditions before work.'
]),
]),
'ad_scaffolding':(
'Scaffolding Safety','view_module_outlined',[
('Design, selection and planning',[
'Select a scaffold system suitable for the height, load, configuration, access and intended use.',
'Ensure design or engineering requirements are addressed for complex, unusual or high-load configurations.',
'Consider ground condition, foundation, tie arrangement, wind exposure and adjacent structures.',
'Prevent incompatible components or uncontrolled modifications.',
'Plan safe erection, alteration and dismantling sequences before work starts.',
'Provide suitable access, edge protection, toe protection and material-handling arrangements.',
'Apply current ADOSH-SF CoP 26 and manufacturer or design requirements.'
]),
('Erection and dismantling',[
'Use trained and competent scaffold personnel for erection, alteration and dismantling.',
'Establish an exclusion zone to protect people from falling materials and incomplete structures.',
'Follow the planned sequence and maintain stability throughout the work.',
'Install ties, bracing, platforms and access progressively as required by the system design.',
'Prevent unauthorised persons from using incomplete or unsafe scaffolds.',
'Control weather conditions, especially high winds and unstable ground conditions.',
'Inspect after significant alterations before releasing the scaffold for use.'
]),
('Inspection and tagging',[
'Inspect scaffolds at the frequency required by the applicable standard, project procedure and risk.',
'Inspect after erection, alteration, adverse weather, impact or other events that may affect integrity.',
'Use a clear status or tagging system to communicate whether the scaffold is safe for intended use.',
'Remove or isolate defective scaffolds from use until repaired and re-inspected.',
'Check foundations, standards, ledgers, braces, ties, platforms, guardrails and access.',
'Check load limits and ensure users do not exceed intended capacity.',
'Keep inspection records traceable to the scaffold or work location.'
]),
('Safe use and user controls',[
'Keep platforms clear, stable and suitable for the intended work.',
'Prevent unauthorised removal of guardrails, ties, boards or other structural components.',
'Control material storage and loading to avoid overloading or instability.',
'Provide safe access and prevent climbing on outside structural members unless designed for access.',
'Control interaction with cranes, MEWPs, vehicles and other plant.',
'Prevent work from being carried out beneath scaffold where falling-object risk is uncontrolled.',
'Ensure users report defects immediately and stop using unsafe structures.'
]),
('Weather and environmental conditions',[
'Assess wind and weather conditions for the scaffold configuration and task.',
'Inspect after strong winds, heavy rain, impact or other events affecting stability.',
'Control dust, mud or contamination that can create slip hazards on platforms.',
'Provide adequate lighting for access and work.',
'Prevent water accumulation or drainage problems affecting foundations.',
'Consider heat exposure for scaffold erection crews and provide suitable work-rest and hydration arrangements.',
'Coordinate scaffold use with temporary electrical systems and overhead services.'
]),
('Interface and modification control',[
'Coordinate scaffold changes with the responsible scaffold competent person.',
'Prohibit ad hoc removal or relocation of structural components by other trades.',
'Control attachment of sheeting, signs or materials that may alter wind loading.',
'Assess interfaces with excavation, formwork, temporary works and building edges.',
'Coordinate scaffold access with lifting operations and material delivery routes.',
'Communicate status changes to all affected contractors.',
'Reinspect after any approved modification before reuse.'
]),
('Field verification and learning',[
'Check scaffold status before each shift or use where required by project arrangements.',
'Ask workers to identify the scaffold\'s intended use, load limits and prohibited modifications.',
'Inspect high-risk scaffold configurations more frequently based on risk.',
'Check tags, inspection records and physical condition agree.',
'Investigate scaffold-related near misses and repeated defects for systemic causes.',
'Keep defective components segregated so they are not accidentally reused.',
'Verify current ADOSH-SF CoP 26 requirements before compliance decisions.'
]),
]),
'ad_lifting_operations':(
'Lifting Operations and Crane Safety','precision_manufacturing_outlined',[
('Lift planning and classification',[
'Plan every lift according to load characteristics, equipment capacity, location, path and environmental conditions.',
'Identify routine, non-routine and critical lifts according to the project lifting procedure.',
'Confirm load weight, dimensions, centre of gravity and lifting points before selecting equipment.',
'Plan the load path, set-down area and exclusion zone before lifting.',
'Assess nearby structures, overhead services, excavation edges, traffic and public interfaces.',
'Provide a written lift plan and competent supervision for lifts requiring formal planning.',
'Reassess when the load, equipment, location or environmental conditions change.'
]),
('Crane and lifting equipment selection',[
'Select equipment with adequate rated capacity for the actual configuration and lift radius.',
'Verify current inspection, certification and third-party requirements applicable to the equipment.',
'Check ground bearing capacity, crane setup, outriggers, mats and stability.',
'Use manufacturer load charts and configuration limits correctly.',
'Inspect hooks, ropes, chains, slings, shackles, spreader beams and accessories before use.',
'Quarantine defective lifting equipment and prevent reuse until authorised release.',
'Ensure equipment operators and lifting personnel hold required competence or authorisation.'
]),
('Rigging and load control',[
'Select lifting accessories suitable for the load, angle, temperature and attachment method.',
'Protect slings from sharp edges and prevent damage during lifting.',
'Ensure shackles, hooks and lifting points are correctly engaged and secured.',
'Control load stability and prevent unexpected movement or rotation.',
'Use tag lines where appropriate and keep personnel away from suspended loads.',
'Never exceed rated capacity or improvise lifting points without engineering approval.',
'Inspect rigging arrangements before the lift and after significant changes.'
]),
('Communication and exclusion zones',[
'Use a clear communication method between operator, banksman and lifting supervisor.',
'Use a designated signal system and ensure the operator can understand the signaler.',
'Establish and enforce an exclusion zone around the lifting path and landing area.',
'Prevent people from standing under suspended loads.',
'Control pedestrian and vehicle interfaces around lifting operations.',
'Use barriers and spotters where physical separation is difficult.',
'Stop the lift if communication is lost or unauthorised people enter the exclusion zone.'
]),
('Critical and complex lifts',[
'Use enhanced planning and approval for lifts involving high consequence, limited clearances, tandem cranes or unusual loads.',
'Consider load dynamics, wind, ground condition and crane configuration throughout the lift.',
'Conduct a pre-lift meeting with all critical personnel.',
'Confirm emergency arrangements for load instability, equipment failure or loss of communication.',
'Use trial lifts where appropriate to verify balance, rigging and clearances.',
'Control changes through the lifting supervisor and formal reassessment.',
'Document critical-lift evidence according to project requirements.'
]),
('Weather, visibility and site conditions',[
'Check wind speed and other environmental limits before and during lifting.',
'Consider rain, fog, dust, poor visibility and lightning where relevant.',
'Ensure lighting is adequate for night or low-visibility operations.',
'Keep crane setup areas free from undermining, standing water and unstable ground.',
'Control lifting near overhead electrical lines according to approved procedures and authority requirements.',
'Suspend lifting when conditions exceed equipment, manufacturer or project limits.',
'Reinspect the setup after adverse weather or ground changes.'
]),
('Field verification and records',[
'Verify operator, rigger, banksman and supervisor competence before the lift.',
'Check equipment certification, inspection status and lifting accessory identification.',
'Compare actual lift conditions with the approved lift plan.',
'Observe exclusion zones and communication during the lift.',
'Record significant lift inspections, defects and corrective actions.',
'Investigate lifting near misses and dropped-load events for control failures.',
'Verify current authority and third-party inspection requirements before lifting operations.'
]),
]),
'ad_confined_space':(
'Confined Space Entry and Rescue','door_open_outlined',[
('Identification and hazard assessment',[
'Identify spaces with restricted entry or exit, limited ventilation or other characteristics that can create serious risk.',
'Assess oxygen deficiency or enrichment, toxic or flammable atmospheres and engulfment hazards.',
'Consider mechanical, electrical, hydraulic, thermal and stored-energy hazards inside the space.',
'Assess biological, contamination and physical hazards such as heat, poor visibility and restricted movement.',
'Consider the work process itself, including welding, cleaning, chemical use or inerting.',
'Determine whether the space meets the project definition requiring a confined-space permit or specialist controls.',
'Reassess when conditions or tasks change.'
]),
('Permit, isolation and entry control',[
'Use a controlled permit-to-work process where required for confined-space entry.',
'Isolate electrical, mechanical, process, pressure and material sources before entry.',
'Verify isolation rather than relying only on a switch position or verbal confirmation.',
'Control entry and exit through an authorised entry point and maintain an entrant register.',
'Define permitted personnel, time limits, communication and emergency arrangements.',
'Suspend the permit when conditions change or required controls fail.',
'Close and archive the permit after the space is made safe and all personnel are accounted for.'
]),
('Atmospheric testing and ventilation',[
'Test the atmosphere with calibrated equipment suitable for the hazards identified.',
'Check oxygen and relevant toxic, flammable or contaminant parameters before entry.',
'Continue or repeat monitoring at a frequency based on risk and the potential for changing conditions.',
'Position sampling points to represent the atmosphere in different areas or elevations where required.',
'Provide mechanical ventilation when needed and ensure it does not introduce additional hazards.',
'Prevent contamination sources from entering the space during the work.',
'Withdraw entrants immediately when alarm conditions or unacceptable readings occur.'
]),
('Entry equipment and PPE',[
'Use suitable harnesses, retrieval systems, lighting, communication and respiratory protection where required by the risk assessment.',
'Ensure rescue equipment is compatible with the space geometry and entry method.',
'Inspect equipment before use and maintain it in serviceable condition.',
'Control ignition sources where flammable atmospheres may occur.',
'Provide intrinsically safe or otherwise suitable equipment where required by the hazard assessment.',
'Ensure PPE does not interfere with communication, movement or rescue.',
'Train workers in equipment limitations and emergency actions.'
]),
('Standby, communication and rescue',[
'Provide a competent standby attendant when required by the confined-space system.',
'Ensure the attendant continuously monitors entrants and does not leave the post without authorised replacement.',
'Provide reliable communication appropriate to the environment.',
'Prepare a rescue plan before entry and ensure trained rescuers and equipment are available.',
'Never send an unprotected person into a confined space to rescue another worker.',
'Coordinate external emergency services when specialist rescue capability is required.',
'Conduct rescue drills appropriate to the space and task.'
]),
('Emergency response and medical considerations',[
'Plan for atmospheric poisoning, oxygen deficiency, fire, flooding, engulfment, injury and equipment failure as applicable.',
'Ensure emergency responders can access the space and casualty extraction route.',
'Provide first aid and medical arrangements suitable for the identified exposures.',
'Consider heat stress and physiological effects in poorly ventilated or hot spaces.',
'Ensure emergency information identifies the space, access route and hazards.',
'Review response arrangements after drills, near misses or changes in space configuration.',
'Keep rescue equipment immediately available rather than stored far from the entry point.'
]),
('Field verification and permit closure',[
'Conduct a pre-entry verification of isolation, atmosphere, access, communication, standby and rescue readiness.',
'Ask entrants to explain alarm response and evacuation triggers.',
'Check atmospheric monitoring records during the work.',
'Confirm the attendant maintains the entry log and communication.',
'Stop work immediately if atmospheric readings or other critical controls become unacceptable.',
'Account for all personnel before closing the permit and returning the space to normal service.',
'Verify current ADOSH-SF CoP 27 and project permit requirements before entry.'
]),
]),
'ad_excavation':(
'Excavation and Trenching Safety','terrain_outlined',[
('Planning, survey and design',[
'Identify excavation scope, depth, soil condition, adjacent structures, utilities and surrounding loads before digging.',
'Obtain required drawings, utility information, permits, approvals and survey data.',
'Use competent assessment of ground conditions and temporary support requirements.',
'Consider dewatering, groundwater, weather and nearby vibration sources.',
'Plan spoil placement, plant routes, access, egress and emergency rescue arrangements.',
'Consider existing structures, roads, foundations and public interfaces that may be affected.',
'Apply current ADOSH-SF CoP 29 and project-specific excavation requirements.'
]),
('Underground services and safe digging',[
'Identify electrical, water, gas, telecommunications and other underground services before excavation.',
'Use approved service drawings, locating equipment and physical verification methods as required.',
'Control mechanical excavation near services according to approved procedures.',
'Protect exposed services from damage and provide support where required.',
'Use permit-to-dig controls and define the excavation boundary.',
'Stop work if an unidentified service or unexpected condition is encountered.',
'Record service information and communicate it to all excavation teams.'
]),
('Ground stability and protective systems',[
'Assess soil and ground conditions and select battering, benching, shoring or shielding as appropriate.',
'Ensure protective systems are designed or selected by competent persons for the actual excavation.',
'Prevent workers from entering unsupported or unstable excavations.',
'Keep spoil, materials and heavy plant away from edges as required by the risk assessment and support design.',
'Control water ingress and erosion that can undermine stability.',
'Inspect support systems for movement, damage or deterioration.',
'Immediately evacuate and reassess when cracking, movement, water or other instability indicators appear.'
]),
('Access, egress and worker protection',[
'Provide safe access and egress at appropriate intervals for the excavation configuration.',
'Keep ladders, ramps and walkways stable, secured and free from obstruction.',
'Protect open edges with barriers or other controls where people or vehicles may fall.',
'Provide lighting for work and access where visibility is limited.',
'Control worker exposure to plant operating near the excavation edge.',
'Prevent workers from entering beneath suspended loads or unstable overhangs.',
'Communicate emergency escape routes before work begins.'
]),
('Plant, traffic and adjacent structures',[
'Control mobile plant movement and reversing near excavation edges.',
'Provide physical separation between vehicles and pedestrian access where possible.',
'Assess vibration from compaction, piling or traffic for effects on excavation stability.',
'Protect adjacent buildings, walls, roads and services from undermining.',
'Control lifting and material handling over or near excavations.',
'Prevent uncontrolled water discharge into excavations.',
'Review the excavation when site layout or construction sequence changes.'
]),
('Inspection and daily control',[
'Inspect excavations and protective systems at the frequency required by the project procedure and risk.',
'Inspect after rain, flooding, vibration, collapse indicators or other events affecting stability.',
'Check access, edge protection, spoil placement, water control and service protection.',
'Keep inspection records linked to the excavation location and date.',
'Ensure only authorised competent persons permit entry after inspection.',
'Close or barricade excavations when not actively controlled.',
'Escalate defects that cannot be corrected immediately.'
]),
('Emergency and rescue',[
'Plan rescue for collapse, flooding, hazardous atmosphere, service strike and worker injury.',
'Provide suitable emergency access and communication arrangements.',
'Prevent unplanned entry into collapsed or unstable ground during rescue.',
'Coordinate specialist rescue resources when the site cannot safely self-rescue.',
'Provide first aid and emergency contact information at the work area.',
'Use incidents and near misses to review ground-control assumptions.',
'Verify current CoP 29 and project requirements before excavation begins.'
]),
]),
'ad_electrical_safety':(
'Electrical Safety and Isolation','bolt_outlined',[
('Electrical risk assessment',[
'Identify fixed, temporary, portable and overhead electrical hazards before work begins.',
'Consider electric shock, arc flash, burns, fire, unexpected energisation and stored electrical energy.',
'Identify competent persons and define limits of electrical work they may perform.',
'Assess environmental conditions such as wet areas, conductive structures and restricted spaces.',
'Consider interactions with cranes, scaffolds, excavation and temporary works near electrical services.',
'Use engineered protection and isolation before relying on administrative controls.',
'Apply current ADOSH-SF CoP 15 and project electrical procedures.'
]),
('Isolation and LOTO',[
'Identify all energy sources and isolation points before maintenance or intrusive work.',
'Use lockout and tagout procedures appropriate to the equipment and task.',
'Verify isolation through an approved test-before-touch or equivalent verification method.',
'Control stored energy including capacitors, batteries, hydraulic or mechanical systems connected to electrical equipment.',
'Ensure each worker requiring personal protection applies the required lock or control.',
'Control group isolations through an authorised process.',
'Restore energy only after work completion, tool removal, personnel clearance and authorised release.'
]),
('Temporary electrical systems',[
'Design and install temporary electrical systems to suitable standards and project requirements.',
'Protect cables from mechanical damage, water, traffic and sharp edges.',
'Provide suitable distribution boards, residual-current protection and earthing as required.',
'Keep electrical panels accessible, identified and protected from unauthorised operation.',
'Inspect and test temporary systems at defined intervals and after changes.',
'Prevent makeshift joints, damaged plugs, exposed conductors or overloaded outlets.',
'Keep records of inspections, tests, defects and corrective actions.'
]),
('Electrical equipment and tools',[
'Use tools and equipment suitable for the voltage, environment and task.',
'Inspect portable electrical equipment, leads, plugs and guards before use.',
'Remove damaged equipment from service immediately and prevent accidental reuse.',
'Use appropriate protective devices and extension arrangements.',
'Control battery charging and storage areas to reduce fire and electrical risks.',
'Ensure only competent persons perform repairs or electrical modifications.',
'Follow manufacturer instructions and project inspection requirements.'
]),
('Work near electrical services',[
'Identify overhead and underground services before excavation, lifting or access work.',
'Maintain required exclusion distances and use competent planning for work near live systems.',
'Use barriers, goalposts, spotters or other controls where appropriate.',
'Coordinate crane, scaffold and MEWP operations near overhead lines.',
'Use service-locating and permit-to-dig controls for underground electrical services.',
'Treat unidentified services as potentially live until verified safe by an authorised competent person.',
'Plan emergency response for contact with electrical services.'
]),
('Arc flash, fire and emergency response',[
'Assess arc-flash and fault-energy hazards for electrical tasks where applicable.',
'Use appropriate boundaries, PPE and switching procedures based on the task and equipment.',
'Control combustible materials around electrical installations.',
'Provide suitable firefighting and emergency arrangements for electrical incidents.',
'Do not use water on energised electrical equipment unless the approved emergency procedure specifically permits it.',
'Provide first aid and emergency medical response for electrical shock.',
'Investigate electrical incidents and near misses for system-level causes.'
]),
('Inspection and field verification',[
'Check isolation points, labels, protective devices, earthing and physical condition.',
'Verify that workers understand the isolation and do not bypass safety devices.',
'Inspect temporary distribution and cable routing in active work areas.',
'Check electrical equipment inspection status before use.',
'Confirm only authorised persons perform electrical work.',
'Stop work when damaged equipment, missing protection or unexpected energisation is identified.',
'Verify current CoP 15 and CoP 24 isolation requirements where applicable.'
]),
]),
'ad_hot_work':(
'Hot Work, Welding and Cutting','local_fire_department_outlined',[
('Hot-work assessment and permit',[
'Identify welding, cutting, brazing, grinding and other ignition-producing activities requiring hot-work controls.',
'Use a permit system where required and define the exact location, duration and scope of the work.',
'Assess combustible materials, flammable liquids, gases, dusts and adjacent processes.',
'Check whether cold-work methods can eliminate the ignition source.',
'Identify required fire protection, gas testing, fire watch and post-work monitoring.',
'Coordinate hot work with simultaneous operations and enclosed or occupied areas.',
'Apply current ADOSH-SF CoP 28 and project hot-work procedures.'
]),
('Work area preparation',[
'Remove or protect combustible materials within the identified hazard zone.',
'Cover openings and prevent sparks or slag from travelling to lower levels or adjacent areas.',
'Provide suitable fire extinguishers and maintain clear access.',
'Check surrounding areas, voids, ducts and hidden spaces for combustible hazards.',
'Control flammable gases and liquids and ensure containers are properly isolated or removed.',
'Provide barriers to protect nearby workers from sparks, radiation and fumes.',
'Inspect the area after relocation or changes in work sequence.'
]),
('Fire watch and post-work monitoring',[
'Provide competent fire-watch personnel when required by the risk assessment or permit.',
'Ensure the fire watch has no conflicting duties that prevent continuous observation.',
'Check adjacent and lower areas for hidden ignition or smouldering material.',
'Maintain fire watch for the duration required by the permit or project procedure after work stops.',
'Ensure fire-watch personnel know alarm, extinguisher and evacuation arrangements.',
'Escalate any fire, smoke or heat indication immediately.',
'Record permit close-out and post-work inspection where required.'
]),
('Gas cylinders and equipment',[
'Secure gas cylinders upright and protect them from impact, heat and unauthorised access.',
'Use correct regulators, hoses, flashback arrestors and fittings for the gas and equipment.',
'Inspect hoses and connections for damage and leaks before use.',
'Keep oxygen and fuel gases separated according to applicable requirements and site procedures.',
'Close cylinder valves when not in use and remove cylinders from the work area when appropriate.',
'Keep cylinders away from ignition, vehicle impact and excessive heat.',
'Ensure only competent personnel perform equipment setup and repairs.'
]),
('Welding, cutting and grinding controls',[
'Use suitable welding screens to protect nearby personnel from arc radiation.',
'Provide local ventilation or respiratory controls for fumes where required.',
'Use suitable eye, face, hand, body and foot protection for the process.',
'Control grinding sparks and wheel integrity for abrasive work.',
'Inspect welding machines, leads, earth connections and guards before use.',
'Keep electrical equipment protected from wet or conductive conditions.',
'Prevent hot materials from being left where they can ignite combustibles.'
]),
('Enclosed areas and special hazards',[
'Apply confined-space controls where hot work occurs in a confined space.',
'Consider atmospheric testing for flammable or toxic contaminants where required.',
'Control coatings, residues and containers that may release hazardous vapours when heated.',
'Ensure ventilation does not spread fumes or sparks into occupied areas.',
'Coordinate hot work with fire alarm impairment or detection-system arrangements where applicable.',
'Use gas-free or equivalent verification procedures for tanks and process equipment where required.',
'Obtain specialist approval for unusual or high-consequence hot work.'
]),
('Field verification and emergency response',[
'Check the permit, work area, fire equipment and gas-cylinder setup before ignition.',
'Confirm workers know emergency contacts and fire response arrangements.',
'Inspect adjacent areas during the work and after completion.',
'Stop hot work when permit conditions change or fire protection becomes ineffective.',
'Investigate fires, near fires and repeated permit violations for systemic causes.',
'Keep hot-work records and close permits properly.',
'Verify current CoP 28 and project fire-prevention requirements before work.'
]),
]),
'ad_traffic_management':(
'Construction Traffic and Road Interface Management','traffic_outlined',[
('Traffic management planning',[
'Develop a traffic management plan appropriate to site layout, public roads, vehicle types and work phases.',
'Separate pedestrians and vehicles wherever reasonably practicable.',
'Identify entry, exit, loading, unloading, parking, reversing and emergency routes.',
'Consider public road interfaces, adjacent properties, schools, businesses and vulnerable road users where applicable.',
'Use suitable signs, barriers, lighting and traffic-control arrangements.',
'Review traffic arrangements whenever site layout or construction sequence changes.',
'Apply current ADOSH-SF road-work requirements and DMT/project conditions.'
]),
('Pedestrian protection',[
'Provide clearly defined pedestrian routes separated from moving vehicles.',
'Protect crossings with barriers, controlled points or competent marshals where required.',
'Keep walkways free of materials, plant and trip hazards.',
'Provide adequate lighting and visibility at crossings and access points.',
'Control pedestrian movement during deliveries and lifting operations.',
'Provide safe routes for workers with mobility or accessibility needs where relevant.',
'Communicate temporary route changes before implementation.'
]),
('Vehicle and plant movement',[
'Control vehicle speeds according to site risk and project rules.',
'Use competent drivers and operators with appropriate authorisation.',
'Plan reversing out where reasonably practicable and use trained banksmen when required.',
'Fit and maintain reversing alarms, cameras, lights or proximity controls as appropriate.',
'Control blind spots and maintain safe separation from pedestrians.',
'Prevent unauthorised parking or obstruction of emergency routes.',
'Inspect vehicle condition and safety-critical systems before use.'
]),
('Loading, unloading and deliveries',[
'Plan delivery routes and timing to reduce interaction with workers and public traffic.',
'Provide stable loading and unloading areas with adequate space.',
'Control reversing and positioning during deliveries.',
'Keep workers outside vehicle blind spots and unsafe loading zones.',
'Use lifting equipment and banksmen where manual or mechanical handling requires them.',
'Secure loads during transport and prevent material falling onto roads or walkways.',
'Coordinate abnormal loads or oversized deliveries through approved planning.'
]),
('Road works and public interface',[
'Use approved traffic control arrangements for work affecting public roads.',
'Provide advance warning, barriers and safe transition zones appropriate to the work.',
'Control lane closures, diversions and temporary pedestrian routes through competent planning.',
'Ensure traffic-control personnel are trained and positioned safely.',
'Provide night-time visibility and lighting for temporary traffic arrangements.',
'Inspect traffic controls regularly and after impact or weather events.',
'Coordinate with relevant road authorities and emergency services where required.'
]),
('Environmental and visibility risks',[
'Consider dust, fog, rain, glare and low visibility when planning vehicle movement.',
'Use lighting and reflective devices suitable for the traffic environment.',
'Apply reduced-speed or suspension arrangements when visibility becomes unsafe.',
'Control mud and debris on public roads and site routes.',
'Maintain drainage to prevent standing water affecting traffic stability.',
'Consider heat and fatigue for drivers and traffic marshals.',
'Communicate weather-related changes to drivers and supervisors.'
]),
('Inspection, incidents and verification',[
'Inspect barriers, signs, routes, lighting and separation controls routinely.',
'Observe driver and pedestrian behaviour at high-risk points.',
'Investigate vehicle incidents, near misses and reversing events.',
'Track recurring traffic-control failures and implement engineering improvements.',
'Verify emergency access remains available at all times.',
'Update the traffic plan after significant incidents or layout changes.',
'Verify current CoP 33 and related DMT requirements before road-interface work.'
]),
]),
'ad_occupational_health':(
'Occupational Health and Exposure Management','health_and_safety_outlined',[
('Exposure identification and assessment',[
'Identify occupational health hazards associated with chemicals, dust, noise, vibration, heat, ergonomics and biological agents.',
'Assess exposure routes, duration, frequency and affected worker groups.',
'Use competent occupational hygiene assessment where exposure cannot be reliably evaluated by observation alone.',
'Consider combined exposures and vulnerable worker groups where relevant.',
'Use exposure information to select engineering, administrative and PPE controls.',
'Review assessments when processes, materials or equipment change.',
'Link occupational health findings to the project risk register and control programme.'
]),
('Health surveillance and medical fitness',[
'Identify tasks that require pre-placement or periodic health surveillance under applicable requirements.',
'Use competent medical providers and maintain appropriate confidentiality of health information.',
'Ensure fitness decisions are communicated in a way that protects personal medical information.',
'Follow up abnormal surveillance results through appropriate occupational-health processes.',
'Prevent assignment to safety-critical tasks when required fitness criteria are not met.',
'Review surveillance programmes when exposure profiles change.',
'Keep only the health information necessary for authorised work and compliance purposes.'
]),
('Noise and vibration',[
'Identify high-noise equipment and tasks and assess exposure where required.',
'Prefer quieter equipment, isolation and engineering controls before relying on hearing protection.',
'Control exposure duration and provide suitable hearing protection when required.',
'Assess hand-arm and whole-body vibration from tools and mobile plant as applicable.',
'Maintain equipment to reduce unnecessary vibration and noise.',
'Provide health surveillance where required by exposure and applicable requirements.',
'Use measurement results to verify control effectiveness.'
]),
('Dust, fumes and chemical exposure',[
'Identify hazardous substances, dusts, welding fumes and other airborne contaminants.',
'Use substitution, enclosure, local exhaust ventilation and process controls where feasible.',
'Prevent dry sweeping or uncontrolled dust generation where safer methods are available.',
'Provide suitable respiratory protection when residual exposure remains and ensure fit and competence requirements are met.',
'Maintain chemical inventories, safety data information and storage controls.',
'Provide spill and emergency arrangements for hazardous substances.',
'Investigate symptoms, monitoring results or incidents indicating control failure.'
]),
('Heat, welfare and worker wellbeing',[
'Integrate heat stress management with occupational health planning during hot conditions.',
'Provide suitable drinking water, rest arrangements and work-rest controls according to risk and applicable requirements.',
'Consider fatigue, sleep, transport and workload factors that can affect safety.',
'Provide welfare facilities, sanitation and hygiene appropriate to the workforce and site.',
'Promote early reporting of symptoms and health concerns.',
'Provide arrangements for workers who need temporary work modification or medical review.',
'Use health trends and field observations to improve controls.'
]),
('Ergonomics and manual work',[
'Assess repetitive, forceful, awkward or prolonged tasks for musculoskeletal risk.',
'Use mechanical aids, improved layout and task redesign before relying on worker technique alone.',
'Provide suitable work heights and access where practical.',
'Rotate or redesign tasks where exposure remains significant and rotation does not simply transfer risk.',
'Train workers in safe use of handling aids and task-specific techniques.',
'Investigate discomfort and early symptoms as indicators of control weakness.',
'Use worker feedback to improve ergonomic controls.'
]),
('Monitoring, records and field verification',[
'Plan occupational hygiene monitoring based on risk and applicable requirements.',
'Keep calibration and measurement records for monitoring equipment where used.',
'Compare results with applicable exposure criteria and take action when limits or internal triggers are exceeded.',
'Protect confidential medical information and restrict access to authorised personnel.',
'Verify controls at the workface through inspection and observation.',
'Use incident and health trends to identify emerging occupational risks.',
'Verify current ADOSH-SF Codes of Practice for the specific exposure before making compliance decisions.'
]),
]),
'ad_heat_stress':(
'Heat Stress Management and Summer Work','wb_sunny_outlined',[
('Heat risk assessment',[
'Identify heat exposure from ambient temperature, humidity, radiant heat, workload, clothing and work location.',
'Consider worker acclimatisation, fitness, hydration, medication factors and individual vulnerability through appropriate occupational-health processes.',
'Classify tasks by physical workload and heat exposure so controls match actual risk.',
'Plan work timing and sequencing to reduce peak heat exposure.',
'Consider heat risk for outdoor, indoor hot-process and poorly ventilated work areas.',
'Use current ADPHC heat-safety requirements and DMT implementation requirements applicable to construction.',
'Reassess heat risk when weather, work intensity or work location changes.'
]),
('Work-rest-hydration controls',[
'Provide readily accessible potable drinking water and encourage regular hydration.',
'Provide shaded or otherwise suitable rest areas appropriate to the work and exposure.',
'Adjust work-rest arrangements to the heat conditions and workload using the approved project programme.',
'Use job rotation or mechanisation where it reduces individual heat load without transferring risk.',
'Plan heavy work for cooler periods where practicable.',
'Ensure workers can report symptoms and take appropriate recovery action without delay.',
'Check that heat controls are available at remote work fronts, not only at the main welfare area.'
]),
('Acclimatisation and worker readiness',[
'Provide a structured approach for workers newly exposed to high heat or returning after absence where required by the heat-management programme.',
'Increase workload progressively rather than immediately assigning maximum physical demand.',
'Provide heat-safety information during induction and seasonal refreshers.',
'Ensure supervisors recognise workers who may need additional monitoring or support.',
'Coordinate occupational-health advice for workers with relevant medical considerations.',
'Consider heat exposure during overtime, night work and high-intensity tasks.',
'Keep records required by the project heat-stress programme.'
]),
('Recognition of heat illness',[
'Teach workers and supervisors to recognise early symptoms of heat exhaustion and more serious heat illness.',
'Use a clear response process: stop exposure, move to a cooler location, provide appropriate first aid and obtain medical assistance when required.',
'Treat altered mental status, collapse or other severe symptoms as a medical emergency.',
'Never leave a symptomatic worker alone when serious heat illness is suspected.',
'Ensure emergency contacts and response routes are known to supervisors.',
'Review incidents to identify why preventive controls did not work.',
'Communicate lessons without blaming affected workers.'
]),
('Midday work restriction and scheduling',[
'Identify the applicable seasonal midday work restrictions and official implementation dates for the current year.',
'Plan work programmes so restricted activities are not simply moved into another unsafe exposure period.',
'Provide required rest, hydration and shaded arrangements for permitted activities where applicable.',
'Control exemptions or specialised work only through the current official rules and approvals.',
'Communicate schedules to workers and contractors before the season begins.',
'Monitor compliance through field inspections and supervisor checks.',
'Verify current DMT and relevant UAE requirements each season because dates and official instructions can change.'
]),
('Supervision and monitoring',[
'Assign supervisors to actively monitor workers during high heat conditions.',
'Check water, shade, rest and communication arrangements at the workface.',
'Use heat-stress observations and weather information to trigger additional controls.',
'Encourage buddy checks for symptoms during high-risk work.',
'Suspend or modify work when controls cannot keep exposure within the approved safe arrangement.',
'Investigate heat-related near misses and medical cases.',
'Use trend data to improve seasonal planning.'
]),
('Field verification and emergency response',[
'Before work, verify water, shade, rest arrangements, communication and emergency access.',
'Ask workers to explain symptoms and what they should do if they feel unwell.',
'Observe whether rest periods are actually taken and whether workers can access water without delay.',
'Check that contractors follow the same project heat-management expectations.',
'Record deficiencies and correct them immediately where possible.',
'Escalate heat-related medical events through the incident system as applicable.',
'Use the latest ADPHC CoP 11 and DMT heat-safety information as the final reference.'
]),
]),
'ad_ppe':(
'Personal Protective Equipment Management','health_and_safety_outlined',[
('PPE selection and risk assessment',[
'Select PPE from the residual risk identified after higher-level controls have been considered.',
'Choose PPE appropriate to the hazard, task, environment, user and duration of exposure.',
'Ensure PPE is compatible when multiple items are worn together.',
'Consider fit, size, visibility, heat load, mobility and communication needs.',
'Use task-specific PPE for chemical, electrical, respiratory, fall, eye, hearing and other hazards as applicable.',
'Consider workers who require special sizes or adaptations.',
'Apply current ADOSH-SF CoP 2 and manufacturer requirements.'
]),
('Hierarchy and limitations',[
'PPE must not be treated as the primary control when elimination or engineering controls are reasonably practicable.',
'Explain the specific hazard PPE controls and what it cannot protect against.',
'Ensure PPE does not create new hazards such as entanglement, heat stress or restricted vision.',
'Use suitable respiratory protection only after exposure assessment and with required competence and fit arrangements.',
'Use fall protection equipment as part of a complete fall-prevention and rescue system.',
'Use electrical PPE appropriate to the energy and task and never as a substitute for isolation.',
'Review PPE when the task, material or hazard changes.'
]),
('Issue, fit and user training',[
'Provide PPE without inappropriate barriers to access for workers who need it.',
'Ensure workers know how to select, don, adjust, use, store and inspect PPE.',
'Conduct fit testing or other suitability checks where required for the type of PPE.',
'Provide replacement for damaged, contaminated or expired PPE.',
'Keep records of issue and training where required by the project system.',
'Include contractor workers within project PPE standards.',
'Use worker feedback to improve comfort and practical usability without reducing protection.'
]),
('Inspection and maintenance',[
'Inspect PPE before use and after events that could affect integrity.',
'Follow manufacturer cleaning, maintenance and storage requirements.',
'Quarantine defective PPE so it cannot return to service accidentally.',
'Control service life and replacement intervals where applicable.',
'Keep PPE clean and dry and prevent contamination during storage.',
'Inspect shared or emergency PPE before each use.',
'Record formal inspections for specialist equipment where required.'
]),
('Specialist PPE',[
'Use appropriate hearing protection for identified noise exposure and ensure communication needs are considered.',
'Use eye and face protection suited to impact, chemical splash, radiation or other specific hazards.',
'Use chemical protective clothing compatible with the substance and exposure duration.',
'Use respiratory protective equipment under a managed programme where required.',
'Use arc-rated or electrical protective equipment according to the electrical hazard assessment.',
'Use fall-protection equipment only with suitable anchorage, clearance and rescue arrangements.',
'Ensure specialist PPE is supported by competence and inspection controls.'
]),
('Behaviour, enforcement and worker engagement',[
'Supervisors should verify correct PPE use at the point of work.',
'Address repeated non-use by correcting the underlying control, competence or availability issue rather than relying only on punishment.',
'Ensure PPE requirements are clearly communicated through signage, RAMS and toolbox talks.',
'Investigate cases where PPE is routinely removed because of heat, discomfort or interference with the task.',
'Use worker consultation to identify practical alternatives that maintain protection.',
'Keep PPE requirements consistent across contractor interfaces where shared hazards exist.',
'Review PPE incidents and observations for systemic improvement.'
]),
('Field verification and records',[
'Check that required PPE is available, suitable, correctly fitted and used before exposure.',
'Inspect specialist PPE condition and identification where applicable.',
'Ask workers to explain the hazard and the limitations of their PPE.',
'Check compatibility of multiple PPE items.',
'Confirm defective equipment is quarantined and replaced.',
'Use inspection and incident trends to improve PPE selection and training.',
'Verify current CoP 2 requirements before setting regulatory PPE requirements.'
]),
]),
'ad_environmental_waste':(
'Environmental and Waste Management','recycling_outlined',[
('Environmental planning',[
'Identify environmental aspects and potential impacts from construction activities, materials, waste, water, dust, noise and emissions.',
'Include environmental controls in project planning and method statements where applicable.',
'Identify authority, client and project environmental requirements before work starts.',
'Consider sensitive receptors such as public areas, water bodies, neighbouring properties and drainage systems.',
'Provide spill prevention, waste and housekeeping arrangements appropriate to the project.',
'Control changes that could introduce new environmental impacts.',
'Use current DMT circulars and applicable environmental requirements as the compliance basis.'
]),
('Waste segregation and storage',[
'Segregate waste at source according to the project waste plan and applicable requirements.',
'Provide labelled and suitable containers for different waste streams.',
'Prevent waste accumulation, windblown debris and obstruction of access routes.',
'Keep hazardous waste separated from general waste and control incompatible materials.',
'Use approved collection, transport and disposal arrangements.',
'Keep waste storage areas secure and protected from weather or accidental release where required.',
'Maintain records of waste movements and disposal where required.'
]),
('Hazardous materials and chemicals',[
'Maintain an inventory of hazardous substances and relevant safety information.',
'Store chemicals according to compatibility, container integrity and spill-control requirements.',
'Provide secondary containment where needed to prevent releases to soil or drainage.',
'Control transfer, dispensing and handling to minimise exposure and spills.',
'Provide suitable emergency spill equipment and trained response personnel.',
'Control empty containers and contaminated materials as appropriate waste streams.',
'Apply relevant ADOSH-SF hazardous-material requirements as well as environmental controls.'
]),
('Spill prevention and response',[
'Identify credible spill sources including fuel, oil, chemicals, paints and contaminated water.',
'Use drip trays, bunding, secure storage and good housekeeping to prevent releases.',
'Keep spill kits appropriate to the materials present and accessible near the risk source.',
'Provide response procedures that protect workers from chemical exposure during cleanup.',
'Prevent contaminated material from entering drains or watercourses.',
'Report significant spills according to project and authority requirements.',
'Investigate spills for root causes and improve prevention controls.'
]),
('Dust, noise and nuisance control',[
'Control construction dust through suitable suppression, enclosure, housekeeping or process controls.',
'Prevent uncontrolled burning or waste disposal.',
'Control noise-generating activities through planning, equipment selection and work timing.',
'Consider vibration and other nuisance impacts on neighbouring receptors.',
'Use complaints and monitoring results to identify recurring environmental issues.',
'Maintain roads and work areas to reduce dust and debris transfer.',
'Coordinate environmental controls with occupational health requirements.'
]),
('Monitoring and compliance records',[
'Define environmental inspections and monitoring appropriate to the project risk.',
'Record waste quantities, disposal documentation and environmental incidents where required.',
'Keep permits, approvals, manifests and monitoring results controlled and retrievable.',
'Track environmental corrective actions to verified closure.',
'Review contractor waste and environmental performance.',
'Use trend information to reduce waste and recurring environmental incidents.',
'Verify current DMT circulars and environmental authority conditions before final disposal decisions.'
]),
('Field verification and continual improvement',[
'Inspect waste areas, chemical stores, spill controls, drains and housekeeping routinely.',
'Check that workers know segregation and spill-response requirements.',
'Correct uncontrolled waste or releases immediately where possible.',
'Investigate recurring waste contamination and improve source segregation.',
'Use procurement and design decisions to reduce waste generation.',
'Capture environmental lessons in toolbox talks and contractor reviews.',
'Verify current CoP 54 and project environmental requirements before implementation.'
]),
]),
'ad_inspection_audit':(
'HSE Inspection, Audit and Assurance','fact_check_outlined',[
('Inspection planning',[
'Plan inspections according to risk, work phase, legal requirements, previous findings and critical-control priorities.',
'Define scope, frequency, responsible persons and evidence requirements.',
'Include daily or task-level checks as well as formal management inspections where appropriate.',
'Prioritise high-risk work and areas with repeated failures.',
'Coordinate inspections across contractor and project interfaces.',
'Ensure inspection criteria reflect actual site hazards rather than generic checklists alone.',
'Review the programme when risk or project conditions change.'
]),
('Field inspection technique',[
'Observe work in progress and compare actual conditions with approved controls.',
'Interview workers and supervisors to test understanding of hazards and critical controls.',
'Check physical barriers, equipment condition, access, housekeeping and emergency arrangements.',
'Use photographs or objective evidence where appropriate and permitted.',
'Distinguish critical-control failures from lower-risk housekeeping observations.',
'Identify positive controls as well as deficiencies to support learning.',
'Record findings clearly enough that another person can verify them.'
]),
('Audit methodology',[
'Define audit criteria from current legal requirements, ADOSH-SF documents, project procedures and approved standards.',
'Use evidence sampling rather than relying on management statements alone.',
'Assess both system design and field implementation.',
'Trace selected requirements from policy or procedure to actual records and workface evidence.',
'Keep audit findings factual and supported by evidence.',
'Use competent auditors with sufficient independence and subject knowledge.',
'Protect audit records and maintain version control.'
]),
('Findings and risk classification',[
'Classify findings according to the project system and actual risk significance.',
'Escalate critical or serious findings immediately where required.',
'Describe the requirement, evidence, condition and risk clearly.',
'Avoid vague findings that cannot be actioned or verified.',
'Identify recurring or systemic findings separately from isolated issues.',
'Use trend analysis to identify areas requiring management intervention.',
'Ensure findings are not closed without objective evidence.'
]),
('Corrective actions and close-out',[
'Assign an accountable action owner and realistic risk-based due date.',
'Prefer corrective actions that strengthen engineering or system controls.',
'Require evidence appropriate to the risk and finding type.',
'Verify effectiveness after implementation for significant actions.',
'Reopen actions when the correction is incomplete or ineffective.',
'Escalate overdue critical actions through management governance.',
'Use recurring findings to trigger risk assessment or procedure review.'
]),
('Management review and assurance',[
'Present significant inspection and audit trends to project and senior management.',
'Compare performance across work areas and contractors to identify common weaknesses.',
'Use assurance results to allocate resources and improve planning.',
'Integrate incident, training, environmental and occupational-health trends where relevant.',
'Check whether previous audit recommendations remain effective.',
'Use independent assurance for high-consequence risks when appropriate.',
'Keep management review decisions and actions traceable.'
]),
('Field verification and professional practice',[
'Use checklists as prompts, not as substitutes for competent observation and judgement.',
'Focus on whether critical controls work in practice at the point of exposure.',
'Ask open questions and verify answers through observation.',
'Check conditions during changing work phases, not only at scheduled visits.',
'Use findings to improve controls rather than create unnecessary paperwork.',
'Maintain professional objectivity and evidence-based reporting.',
'Use the current ADPHC Technical Guideline on Audit and Inspection where applicable.'
]),
]),
'ad_performance_monitoring':(
'OSH Performance Monitoring and KPIs','analytics_outlined',[
('Performance framework',[
'Define a balanced set of OSH indicators linked to significant risks and management objectives.',
'Use leading indicators to measure preventive activity and control health.',
'Use lagging indicators to understand outcomes and serious events.',
'Assign owners, data sources, calculation methods and reporting frequency.',
'Ensure indicators are understood consistently across contractors and project teams.',
'Avoid metrics that encourage under-reporting or unsafe behaviour.',
'Review indicators when risk profile or business priorities change.'
]),
('Leading indicators',[
'Monitor critical-control verification, inspections, risk reviews, training and action closure.',
'Track quality of pre-task briefings and worker consultation where meaningful measures exist.',
'Monitor permit compliance and high-risk work assurance.',
'Use proactive observation trends to identify deteriorating conditions early.',
'Monitor equipment inspection and certification status for safety-critical assets.',
'Track contractor performance indicators and recurring findings.',
'Focus on quality and effectiveness rather than activity counts alone.'
]),
('Lagging indicators',[
'Track recordable incidents, lost-time injuries and other outcome measures required by the reporting system.',
'Include high-potential incidents and near misses where the project system uses them as learning indicators.',
'Analyse occupational health cases and environmental incidents where relevant.',
'Normalise data appropriately when comparing projects or workforces of different sizes.',
'Investigate significant changes in trends rather than assuming improvement or deterioration without context.',
'Protect confidentiality when reporting personal incident information.',
'Use lagging data to trigger preventive action rather than only retrospective reporting.'
]),
('Data quality and governance',[
'Define data owners and validation responsibilities for each KPI.',
'Use consistent definitions and reporting periods.',
'Check source records against dashboard summaries for accuracy.',
'Prevent duplicate counting or missing contractor data.',
'Maintain traceability from reported KPI to source evidence.',
'Control revisions to historical data and document material corrections.',
'Use authorised electronic reporting channels where required.'
]),
('Trend analysis and decision making',[
'Analyse trends by project phase, work type, contractor, location and hazard where useful.',
'Identify recurring control failures behind repeated incidents or findings.',
'Use statistical or qualitative trend review appropriate to the amount and quality of data.',
'Compare performance against defined objectives and risk priorities rather than arbitrary benchmarks.',
'Escalate deterioration in critical indicators promptly.',
'Use management review to agree actions, resources and ownership.',
'Check whether interventions produce measurable improvement over time.'
]),
('Reporting and management review',[
'Provide concise dashboards that highlight significant risks and decisions required.',
'Explain important trends and data limitations rather than presenting numbers without context.',
'Include contractor and project interfaces where they materially affect risk.',
'Use reporting to support corrective action and resource allocation.',
'Keep required authority performance submissions accurate and timely.',
'Review performance at appropriate management levels and record decisions.',
'Protect sensitive information and follow project reporting governance.'
]),
('Field verification and improvement',[
'Validate dashboard information through field inspections and record sampling.',
'Compare reported inspection completion with actual inspection quality.',
'Check whether high activity counts correspond to meaningful risk reduction.',
'Use worker feedback to test whether reported performance reflects reality.',
'Investigate discrepancies between records and field conditions.',
'Use trends to strengthen critical controls and training.',
'Verify current ADOSH-SF reporting mechanisms and definitions before regulatory submissions.'
]),
]),
'ad_electronic_reporting':(
'Electronic OSH Reporting and Regulatory Submissions','cloud_upload_outlined',[
('Reporting system governance',[
'Identify which OSH events, performance data and forms must be submitted through prescribed electronic systems.',
'Assign authorised persons responsible for preparation, review, submission and record retention.',
'Maintain access controls so only authorised personnel can submit or amend regulatory information.',
'Keep a controlled register of required submissions, due dates and status.',
'Use the current ADOSH-SF mechanisms and authority instructions as the reporting basis.',
'Provide backup arrangements for critical records without bypassing official submission requirements.',
'Review responsibilities when organisational or project personnel change.'
]),
('Data collection and quality',[
'Capture incident, workforce, performance and project information from controlled source records.',
'Validate dates, locations, classifications, personnel and consequences before submission.',
'Ensure information is complete and internally consistent across forms and supporting records.',
'Correct errors through the authorised process and retain an audit trail where required.',
'Prevent estimates or assumptions from being presented as verified facts.',
'Protect personal and medical information during data handling.',
'Use standard definitions so reporting remains comparable over time.'
]),
('Incident and event reporting',[
'Collect initial facts quickly after an incident while preserving scene evidence.',
'Apply the applicable reporting classification and escalation process.',
'Submit required notifications within the current prescribed timeframe.',
'Link electronic submissions to investigation and corrective-action records.',
'Record submission confirmations or reference numbers for traceability.',
'Update records through authorised follow-up processes when additional facts become available.',
'Prevent duplicate or conflicting reports by assigning clear ownership.'
]),
('Performance reporting',[
'Prepare periodic OSH performance data from verified source records.',
'Check KPI calculations and reporting periods before submission.',
'Reconcile electronic reports with project dashboards and management records.',
'Ensure contractor data is included where the reporting scope requires it.',
'Keep evidence supporting submitted figures.',
'Escalate missing data before submission rather than silently filling gaps.',
'Review authority feedback and update internal processes when reporting requirements change.'
]),
('Document and record control',[
'Keep submitted forms, attachments, approvals and confirmations in a controlled repository.',
'Use unique identifiers and clear naming conventions for electronic records.',
'Control access, retention and disposal according to legal and project requirements.',
'Protect records against unauthorised alteration, deletion or loss.',
'Maintain backups for critical evidence in accordance with information-governance requirements.',
'Ensure records remain retrievable for audits, investigations and authority verification.',
'Link records to the relevant project, incident or performance period.'
]),
('User competence and system continuity',[
'Train authorised users in the current electronic reporting process and data requirements.',
'Provide clear backup responsibility for absence or personnel turnover.',
'Test access and account readiness before critical reporting periods.',
'Keep guidance current when the authority platform or form changes.',
'Prevent shared credentials where the system requires individual accountability.',
'Record system issues and use official support channels when submissions cannot be completed normally.',
'Include electronic reporting in induction or role-specific competence where relevant.'
]),
('Verification and field-to-system traceability',[
'Trace submitted information back to original incident, inspection or performance records.',
'Compare field evidence with electronic records during audits.',
'Investigate discrepancies promptly and correct through the authorised process.',
'Use electronic reporting trends to identify recurring hazards and management-system weaknesses.',
'Ensure corrective actions from reported events are tracked to closure.',
'Periodically test the end-to-end process from field event to final submission and archived evidence.',
'Verify current ADPHC mechanisms and authority instructions before relying on any reporting timeframe or form.'
]),
]),
}

# Convert to Dart.
icons={
'policy_outlined':'Icons.policy_outlined','settings_outlined':'Icons.settings_outlined','rule_outlined':'Icons.rule_outlined','description_outlined':'Icons.description_outlined','groups_outlined':'Icons.groups_outlined','report_outlined':'Icons.report_outlined','school_outlined':'Icons.school_outlined','handshake_outlined':'Icons.handshake_outlined','emergency_outlined':'Icons.emergency_outlined','height_outlined':'Icons.height_outlined','view_module_outlined':'Icons.view_module_outlined','precision_manufacturing_outlined':'Icons.precision_manufacturing_outlined','door_open_outlined':'Icons.door_open_outlined','terrain_outlined':'Icons.terrain_outlined','bolt_outlined':'Icons.bolt_outlined','local_fire_department_outlined':'Icons.local_fire_department_outlined','traffic_outlined':'Icons.traffic_outlined','health_and_safety_outlined':'Icons.health_and_safety_outlined','wb_sunny_outlined':'Icons.wb_sunny_outlined','recycling_outlined':'Icons.recycling_outlined','fact_check_outlined':'Icons.fact_check_outlined','analytics_outlined':'Icons.analytics_outlined','cloud_upload_outlined':'Icons.cloud_upload_outlined'}

def dart_str(x):
    return "'"+x.replace('\\','\\\\').replace("'","\\'").replace('\n',' ') + "'"

out=["const Map<String, List<_AbuDhabiSection>> _abuDhabiDetailedContent = {"]
for key,(title,icon,sections) in data.items():
    out.append(f"  '{key}': [")
    for stitle,sitems in sections:
        out.append('    _AbuDhabiSection(')
        out.append(f'      title: {dart_str(stitle)},')
        out.append(f'      icon: {icons[icon]},')
        out.append('      items: [')
        for item in sitems:
            out.append(f'        {dart_str(item)},')
        out.append('      ],')
        out.append('    ),')
    out.append('  ],')
out.append('};')
new=prefix+'\n'.join(out)+'\n'
p.write_text(new)
print('wrote',len(new),'chars',len(new.splitlines()),'lines')
print('topics',len(data),'sections',sum(len(v[2]) for v in data.values()),'items',sum(len(sec[1]) for v in data.values() for sec in v[2]))
