SafeNexus HSE — Abu Dhabi HSE Professional Learning Library

This update expands the Abu Dhabi reference library from 24 core topics to 54 topics.

CONTENT:
- 54 Abu Dhabi HSE subjects
- 378 expandable learning sections
- 2,646 detailed learning points
- Section tap -> item tap -> detailed field guidance
- 24 existing core topics preserved and expanded
- 30 additional specialist subjects based on the current ADPHC ADOSH-SF Code of Practices catalogue
- Official-reference names included for topic verification

IMPORTANT:
- This is professional learning/reference guidance, not a substitute for current law, authority approval, project procedures or competent professional advice.
- Verify the current ADPHC / ADOSH-SF document version, applicable DMT/municipality requirements and project-specific conditions before implementation.

UPLOAD:
Replace:
lib/data/abu_dhabi_guidelines.dart

The routing file from the previous NO_RED_MARKED_SECTIONS update is unchanged and does not need to be replaced again.
