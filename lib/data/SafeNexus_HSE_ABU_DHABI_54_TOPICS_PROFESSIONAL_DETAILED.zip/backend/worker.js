export default {
  async fetch(request, env) {
    // ============================================================
    // URL
    // ============================================================

    const url = new URL(request.url);

    // ============================================================
    // CORS / PREFLIGHT
    // ============================================================

    if (request.method === "OPTIONS") {
      const origin = request.headers.get("Origin");
      const allowedOrigin = getAllowedOrigin(env);

      if (origin && allowedOrigin && origin !== allowedOrigin) {
        return new Response(null, { status: 403 });
      }

      return new Response(null, {
        status: 204,
        headers: corsHeaders(request, env),
      });
    }

    // ============================================================
    // HEALTH CHECK
    // GET /
    // ============================================================

    if (
      request.method === "GET" &&
      (url.pathname === "/" || url.pathname === "")
    ) {
      return jsonResponse({
        success: true,
        message: "SafeNexus HSE Worker is running",
        status: "online",
      },
        200,
        request,
        env
      );
    }

    // ============================================================
    // ANALYZE HSE ENDPOINT
    // POST /analyze-hse
    // POST /analyze-hse/
    // ============================================================

    const isAnalyzeEndpoint =
      url.pathname === "/analyze-hse" ||
      url.pathname === "/analyze-hse/";

    if (isAnalyzeEndpoint && request.method !== "POST") {
      return jsonResponse(
        {
          success: false,
          error: "Only POST requests are allowed for /analyze-hse.",
        },
        405,
        request,
        env
      );
    }

    // ============================================================
    // BROWSER ORIGIN GUARD
    // ============================================================

    const origin = request.headers.get("Origin");
    const allowedOrigin = getAllowedOrigin(env);

    if (origin && allowedOrigin && origin !== allowedOrigin) {
      return jsonResponse(
        {
          success: false,
          error: "Origin is not allowed.",
        },
        403,
        request,
        env
      );
    }

    // ============================================================
    // UNKNOWN ENDPOINT
    // ============================================================

    if (!isAnalyzeEndpoint) {
      return jsonResponse(
        {
          success: false,
          error: "Endpoint not found.",
        },
        404,
        request,
        env
      );
    }

    // ============================================================
    // API KEY CHECK
    // ============================================================

    if (!env.OPENAI_API_KEY) {
      return jsonResponse(
        {
          success: false,
          error: "OPENAI_API_KEY is not configured.",
        },
        500,
        request,
        env
      );
    }

    try {
      // ==========================================================
      // REQUEST BODY
      // ==========================================================

      let body;

      try {
        body = await request.json();
      } catch (_) {
        return jsonResponse(
          {
            success: false,
            error: "Invalid JSON request body.",
          },
          400,
          request,
          env
        );
      }

      // ==========================================================
      // INPUT VALUES
      // ==========================================================

      const imageBase64 = body?.image_base64;

      const mimeType =
        typeof body?.mime_type === "string"
          ? body.mime_type.toLowerCase().trim()
          : "image/jpeg";

      const description =
        typeof body?.description === "string"
          ? body.description.trim()
          : "";

      const location =
        typeof body?.location === "string"
          ? body.location.trim()
          : "";

      const language =
        typeof body?.language === "string"
          ? body.language.toLowerCase().trim()
          : "en";

      // ==========================================================
      // IMAGE VALIDATION
      // ==========================================================

      if (
        !imageBase64 ||
        typeof imageBase64 !== "string"
      ) {
        return jsonResponse(
          {
            success: false,
            error: "image_base64 is required.",
          },
          400,
          request,
          env
        );
      }

      // ==========================================================
      // CLEAN BASE64
      // ==========================================================

      const cleanBase64 = imageBase64
        .replace(/^data:[^;]+;base64,/i, "")
        .replace(/\s/g, "")
        .trim();

      if (!cleanBase64) {
        return jsonResponse(
          {
            success: false,
            error: "Image data is empty.",
          },
          400,
          request,
          env
        );
      }

      // ==========================================================
      // MIME VALIDATION
      // ==========================================================

      const allowedMimeTypes = [
        "image/jpeg",
        "image/png",
        "image/webp",
      ];

      if (!allowedMimeTypes.includes(mimeType)) {
        return jsonResponse(
          {
            success: false,
            error:
              "Unsupported image type. Use JPEG, PNG or WebP.",
          },
          400,
          request,
          env
        );
      }

      // ==========================================================
      // BASE64 VALIDATION
      // ==========================================================

      const base64Pattern =
        /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;

      if (!base64Pattern.test(cleanBase64)) {
        return jsonResponse(
          {
            success: false,
            error: "Invalid base64 image data.",
          },
          400,
          request,
          env
        );
      }

      // ==========================================================
      // IMAGE SIZE PROTECTION
      // ==========================================================

      const estimatedBytes =
        Math.floor(
          (cleanBase64.length * 3) / 4
        );

      const maxImageBytes =
        10 * 1024 * 1024;

      if (estimatedBytes > maxImageBytes) {
        return jsonResponse(
          {
            success: false,
            error:
              "Image is too large. Maximum allowed size is 10 MB.",
          },
          413,
          request,
          env
        );
      }

      // ==========================================================
      // IMAGE DATA URL
      // ==========================================================

      const imageUrl =
        `data:${mimeType};base64,${cleanBase64}`;

      // ==========================================================
      // RESPONSE LANGUAGE
      // ==========================================================

      const responseLanguage =
        language.startsWith("ml")
          ? "Malayalam"
          : "English";

      // ==========================================================
      // SYSTEM PROMPT
      // ==========================================================

      const systemPrompt = `
You are an expert HSE Safety Observation Analyst.

Analyze workplace images for visible occupational health,
safety and environmental hazards.

IMPORTANT SAFETY RULES:

1. Do not identify people.
2. Do not guess personal identity.
3. Do not infer sensitive personal information.
4. Do not invent hazards.
5. Only report hazards reasonably supported by visible evidence.
6. If the image is unclear, clearly state the limitation.
7. Give practical and realistic HSE corrective actions.
8. Risk level must be exactly:
   Low, Medium, High, or Critical.
9. Observation type must be exactly:
   Unsafe Act, Unsafe Condition, or Positive Observation.
10. Confidence must be a number from 0 to 1.
11. The HSE officer must review the AI result before taking action.
12. Do not claim an unsafe condition is definitely present when
    the image does not provide enough evidence.

CHECK FOR:

- PPE
- Work at height
- Scaffolding
- Electrical safety
- Fire safety
- Lifting and rigging
- Housekeeping
- Slip, trip and fall
- Vehicle and traffic safety
- Chemical safety
- Confined space
- Manual handling
- Machinery safety
- Heat stress
- Environmental safety
- Permit to work
- Barricading
- Access and egress
- Emergency preparedness
- Fall protection
- Excavation safety
- Tools and equipment
- General workplace safety

RISK GUIDANCE:

Low:
Minor issue with limited potential consequence.

Medium:
Potential for injury or moderate operational consequence.

High:
Significant potential for serious injury, major incident or serious
property/environmental impact.

Critical:
Immediate and severe danger with potential for fatality, multiple
serious injuries or major catastrophic consequence.

Do not automatically assign High or Critical simply because a hazard
category exists. Base the risk assessment on visible conditions.

Return the explanation and corrective action in ${responseLanguage}.
`;

      // ==========================================================
      // USER PROMPT
      // ==========================================================

      const userPrompt = `
Analyze the provided workplace image.

Additional observation description:
${description || "No additional description provided."}

Location:
${location || "Location not provided."}

Language:
${responseLanguage}

Return one structured HSE observation based only on visible evidence.
`;

      // ==========================================================
      // OPENAI RESPONSES API
      // ==========================================================

      const openAIResponse = await fetch(
        "https://api.openai.com/v1/responses",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
            "Authorization":
              `Bearer ${env.OPENAI_API_KEY}`,
          },

          body: JSON.stringify({
            model: "gpt-5-mini",

            input: [
              {
                role: "system",
                content: [
                  {
                    type: "input_text",
                    text: systemPrompt,
                  },
                ],
              },

              {
                role: "user",
                content: [
                  {
                    type: "input_text",
                    text: userPrompt,
                  },

                  {
                    type: "input_image",
                    image_url: imageUrl,
                  },
                ],
              },
            ],

            text: {
              format: {
                type: "json_schema",

                name: "hse_observation",

                strict: true,

                schema: {
                  type: "object",

                  additionalProperties: false,

                  properties: {
                    observation_type: {
                      type: "string",
                      enum: [
                        "Unsafe Act",
                        "Unsafe Condition",
                        "Positive Observation",
                      ],
                    },

                    category: {
                      type: "string",
                    },

                    hazard: {
                      type: "string",
                    },

                    risk_level: {
                      type: "string",
                      enum: [
                        "Low",
                        "Medium",
                        "High",
                        "Critical",
                      ],
                    },

                    potential_consequence: {
                      type: "string",
                    },

                    corrective_action: {
                      type: "string",
                    },

                    confidence: {
                      type: "number",
                      minimum: 0,
                      maximum: 1,
                    },

                    explanation: {
                      type: "string",
                    },
                  },

                  required: [
                    "observation_type",
                    "category",
                    "hazard",
                    "risk_level",
                    "potential_consequence",
                    "corrective_action",
                    "confidence",
                    "explanation",
                  ],
                },
              },
            },
          }),
        }
      );

      // ==========================================================
      // READ OPENAI RESPONSE
      // ==========================================================

      const data =
        await openAIResponse.json();

      // ==========================================================
      // OPENAI ERROR
      // ==========================================================

      if (!openAIResponse.ok) {
        console.error(
          "OpenAI API Error:",
          JSON.stringify(data)
        );

        return jsonResponse(
          {
            success: false,
            error:
              data?.error?.message ||
              "OpenAI request failed.",
          },
          openAIResponse.status,
          request,
          env
        );
      }

      // ==========================================================
      // EXTRACT OUTPUT TEXT
      // ==========================================================

      const outputText =
        extractOutputText(data);

      if (!outputText) {
        console.error(
          "OpenAI response did not contain output text:",
          JSON.stringify(data)
        );

        return jsonResponse(
          {
            success: false,
            error:
              "No AI output was returned.",
          },
          502,
          request,
          env
        );
      }

      // ==========================================================
      // PARSE AI JSON
      // ==========================================================

      let result;

      try {
        result =
          JSON.parse(outputText);
      } catch (_) {
        console.error(
          "Invalid AI JSON:",
          outputText
        );

        return jsonResponse(
          {
            success: false,
            error:
              "AI returned invalid JSON.",
          },
          502,
          request,
          env
        );
      }

      // ==========================================================
      // VALIDATE AI RESULT
      // ==========================================================

      const validationError =
        validateHSEResult(result);

      if (validationError) {
        console.error(
          "HSE Result Validation Error:",
          validationError
        );

        return jsonResponse(
          {
            success: false,
            error:
              `Invalid AI result: ${validationError}`,
          },
          502,
          request,
          env
        );
      }

      // ==========================================================
      // SUCCESS
      // ==========================================================

      return jsonResponse({
        success: true,
        result,
      },
        200,
        request,
        env
      );

    } catch (error) {
      // ==========================================================
      // UNEXPECTED ERROR
      // ==========================================================

      console.error(
        "SafeNexus HSE Worker Error:",
        error?.stack || error
      );

      return jsonResponse(
        {
          success: false,
          error:
            error?.message ||
            "Unexpected server error.",
        },
        500,
        request,
        env
      );
    }
  },
};

// ================================================================
// EXTRACT OUTPUT TEXT
// ================================================================

function extractOutputText(data) {
  // --------------------------------------------------------------
  // Preferred Responses API output_text
  // --------------------------------------------------------------

  if (
    typeof data?.output_text === "string" &&
    data.output_text.trim()
  ) {
    return data.output_text.trim();
  }

  // --------------------------------------------------------------
  // Fallback: inspect output messages
  // --------------------------------------------------------------

  if (
    !data?.output ||
    !Array.isArray(data.output)
  ) {
    return null;
  }

  for (const item of data.output) {
    if (item?.type !== "message") {
      continue;
    }

    if (!Array.isArray(item.content)) {
      continue;
    }

    for (const content of item.content) {
      if (
        content?.type === "output_text" &&
        typeof content.text === "string" &&
        content.text.trim()
      ) {
        return content.text.trim();
      }
    }
  }

  return null;
}

// ================================================================
// VALIDATE HSE RESULT
// ================================================================

function validateHSEResult(result) {
  // --------------------------------------------------------------
  // Object validation
  // --------------------------------------------------------------

  if (
    !result ||
    typeof result !== "object" ||
    Array.isArray(result)
  ) {
    return "Result is not an object.";
  }

  // --------------------------------------------------------------
  // Allowed observation types
  // --------------------------------------------------------------

  const allowedObservationTypes = [
    "Unsafe Act",
    "Unsafe Condition",
    "Positive Observation",
  ];

  // --------------------------------------------------------------
  // Allowed risk levels
  // --------------------------------------------------------------

  const allowedRiskLevels = [
    "Low",
    "Medium",
    "High",
    "Critical",
  ];

  // --------------------------------------------------------------
  // Observation type
  // --------------------------------------------------------------

  if (
    !allowedObservationTypes.includes(
      result.observation_type
    )
  ) {
    return "Invalid observation_type.";
  }

  // --------------------------------------------------------------
  // Risk level
  // --------------------------------------------------------------

  if (
    !allowedRiskLevels.includes(
      result.risk_level
    )
  ) {
    return "Invalid risk_level.";
  }

  // --------------------------------------------------------------
  // Required string fields
  // --------------------------------------------------------------

  const requiredStringFields = [
    "category",
    "hazard",
    "potential_consequence",
    "corrective_action",
    "explanation",
  ];

  for (const field of requiredStringFields) {
    if (
      typeof result[field] !== "string" ||
      !result[field].trim()
    ) {
      return `${field} is missing or invalid.`;
    }
  }

  // --------------------------------------------------------------
  // Confidence
  // --------------------------------------------------------------

  if (
    typeof result.confidence !== "number" ||
    !Number.isFinite(result.confidence) ||
    result.confidence < 0 ||
    result.confidence > 1
  ) {
    return "Confidence must be a number between 0 and 1.";
  }

  return null;
}

// ================================================================
// CORS HEADERS
// ================================================================

function getAllowedOrigin(env) {
  const value =
    typeof env?.ALLOWED_ORIGIN === "string"
      ? env.ALLOWED_ORIGIN.trim()
      : "";

  return value || null;
}

function corsHeaders(request, env) {
  const headers = {
    "Access-Control-Allow-Methods":
      "POST, OPTIONS, GET",

    "Access-Control-Allow-Headers":
      "Content-Type, Accept",

    "Access-Control-Max-Age":
      "86400",
  };

  const origin = request?.headers?.get("Origin");
  const allowedOrigin = getAllowedOrigin(env);

  // Native Flutter clients normally send no Origin header and do not
  // require CORS. Browser clients receive CORS only when their origin
  // is explicitly allowed through ALLOWED_ORIGIN.
  if (origin && allowedOrigin && origin === allowedOrigin) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Vary"] = "Origin";
  }

  return headers;
}

// ================================================================
// JSON RESPONSE
// ================================================================

function jsonResponse(
  data,
  status = 200,
  request,
  env
) {
  return new Response(
    JSON.stringify(data),
    {
      status,

      headers: {
        "Content-Type":
          "application/json; charset=utf-8",

        ...corsHeaders(request, env),
      },
    }
  );
}
